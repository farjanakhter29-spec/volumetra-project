import React from 'react';

// Lightweight pure SVG QR code generator (using quickchart or direct SVG matrix)
export function QRCodeSVG({ value, size = 140 }) {
  if (!value) return null;

  // We generate a clean, real QR Code via SVG data URL or dynamic image
  const encoded = encodeURIComponent(value);
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size * 2}x${size * 2}&data=${encoded}&margin=2&format=svg`;

  return (
    <div style={{
      width: size,
      height: size,
      background: '#ffffff',
      borderRadius: 12,
      padding: 8,
      display: 'grid',
      placeItems: 'center',
      boxShadow: '0 4px 14px rgba(0,0,0,0.15)',
      overflow: 'hidden',
    }}>
      <img
        src={qrUrl}
        alt="QR Code"
        style={{ width: '100%', height: '100%', objectFit: 'contain' }}
        loading="lazy"
        onError={(e) => {
          // Fallback if offline
          e.currentTarget.style.display = 'none';
        }}
      />
    </div>
  );
}
