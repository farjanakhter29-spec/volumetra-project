import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

// Read .env
const envPath = path.resolve('.env');
const envContent = fs.readFileSync(envPath, 'utf8');
const envVars = {};
envContent.split('\n').forEach(line => {
  const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
  if (match) {
    let value = match[2] || '';
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    if (value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1);
    envVars[match[1]] = value.trim();
  }
});

const supabaseUrl = envVars.VITE_SUPABASE_URL;
const supabaseAnonKey = envVars.VITE_SUPABASE_PUBLISHABLE_KEY || envVars.VITE_SUPABASE_ANON_KEY;

console.log('=== VOLUMETRA SUPABASE END-TO-END INTEGRATION TEST ===');
console.log('Target Supabase URL:', supabaseUrl);
console.log('Publishable Key present:', Boolean(supabaseAnonKey && supabaseAnonKey.length > 10));

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('ERROR: Supabase URL or Key missing in .env');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Minimal valid GLB binary header & chunk (Cube / empty scene)
function createMinimalGLB() {
  const jsonHeader = JSON.stringify({
    asset: { version: "2.0", generator: "Volumetra Test Generator" },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0 }],
    meshes: [{ primitives: [{ attributes: {} }] }]
  });
  const jsonPadding = (4 - (jsonHeader.length % 4)) % 4;
  const paddedJson = jsonHeader + " ".repeat(jsonPadding);
  const jsonBuffer = Buffer.from(paddedJson, "utf8");

  const totalLength = 12 + 8 + jsonBuffer.length;
  const glb = Buffer.alloc(totalLength);

  // Header: magic (0x46546C67 "glTF"), version (2), length
  glb.writeUInt32LE(0x46546C67, 0);
  glb.writeUInt32LE(2, 4);
  glb.writeUInt32LE(totalLength, 8);

  // Chunk 0: JSON
  glb.writeUInt32LE(jsonBuffer.length, 12);
  glb.writeUInt32LE(0x4E4F534A, 16); // "JSON"
  jsonBuffer.copy(glb, 20);

  return glb;
}

// Minimal 1x1 PNG Buffer
function createMinimalPNG() {
  return Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'base64'
  );
}

async function runTests() {
  const randNum = Math.floor(100000 + Math.random() * 900000);
  const testEmail = `volumetra.test.creator.${randNum}@gmail.com`;
  const testPassword = 'Password_Volumetra_2026!';
  const testName = 'Volumetra Test Creator';

  console.log('\n--- 1. Testing Supabase Auth Signup & Login ---');
  console.log(`Signing up test user: ${testEmail}`);
  
  const { data: authData, error: signupError } = await supabase.auth.signUp({
    email: testEmail,
    password: testPassword,
    options: {
      data: {
        full_name: testName,
        role: 'user',
      }
    }
  });

  if (signupError) {
    console.error('Signup failed:', signupError.message);
    throw signupError;
  }

  const user = authData.user;
  console.log('User signed up successfully. User ID:', user?.id);

  // Sign In
  const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
    email: testEmail,
    password: testPassword
  });

  if (loginError) {
    console.error('Login failed:', loginError.message);
    throw loginError;
  }
  console.log('User logged in successfully with active session.');

  console.log('\n--- 2. Testing Supabase Storage Uploads ---');
  
  // A) Upload Test PNG Image
  const imgBuffer = createMinimalPNG();
  const imgFileId = `img_${Date.now()}`;
  const imgPath = `users/${user.id}/${imgFileId}/render_sample.png`;

  console.log(`Uploading test image to media bucket: ${imgPath}`);
  const { data: imgUpload, error: imgUploadErr } = await supabase.storage
    .from('media')
    .upload(imgPath, imgBuffer, {
      contentType: 'image/png',
      upsert: true
    });

  if (imgUploadErr) {
    console.error('Image Storage upload error:', imgUploadErr.message);
    throw imgUploadErr;
  }
  console.log('Image uploaded to Supabase Storage successfully.');

  const { data: { publicUrl: imgUrl } } = supabase.storage.from('media').getPublicUrl(imgPath);
  console.log('Public URL for image:', imgUrl);

  // Insert image record into media table
  const { data: imgRecord, error: imgDbErr } = await supabase
    .from('media')
    .insert({
      user_id: user.id,
      file_name: 'render_sample.png',
      file_path: imgPath,
      file_url: imgUrl,
      file_type: 'image',
      mime_type: 'image/png',
      file_size: imgBuffer.length,
      title: 'Sample 3D Render Image',
      description: 'Test render image generated during verification',
      is_public: true,
      is_favorite: true,
      views: 1
    })
    .select()
    .single();

  if (imgDbErr) {
    console.error('Database insert for image failed:', imgDbErr.message);
    throw imgDbErr;
  }
  console.log('Media database record for image created:', imgRecord.id);

  // B) Upload Test 3D GLB Model
  const glbBuffer = createMinimalGLB();
  const glbFileId = `glb_${Date.now()}`;
  const glbPath = `users/${user.id}/${glbFileId}/crystal_asset.glb`;

  console.log(`Uploading test 3D GLB to media bucket: ${glbPath}`);
  const { data: glbUpload, error: glbUploadErr } = await supabase.storage
    .from('media')
    .upload(glbPath, glbBuffer, {
      contentType: 'model/gltf-binary',
      upsert: true
    });

  if (glbUploadErr) {
    console.error('GLB Storage upload error:', glbUploadErr.message);
    throw glbUploadErr;
  }
  console.log('3D GLB uploaded to Supabase Storage successfully.');

  const { data: { publicUrl: glbUrl } } = supabase.storage.from('media').getPublicUrl(glbPath);
  console.log('Public URL for 3D GLB:', glbUrl);

  // Insert GLB record into media table
  const { data: glbRecord, error: glbDbErr } = await supabase
    .from('media')
    .insert({
      user_id: user.id,
      file_name: 'crystal_asset.glb',
      file_path: glbPath,
      file_url: glbUrl,
      file_type: '3d',
      mime_type: 'model/gltf-binary',
      file_size: glbBuffer.length,
      title: 'Interactive Crystal 3D Asset',
      description: 'Test GLB asset uploaded to cloud storage',
      is_public: true,
      is_favorite: false,
      views: 5
    })
    .select()
    .single();

  if (glbDbErr) {
    console.error('Database insert for GLB failed:', glbDbErr.message);
    throw glbDbErr;
  }
  console.log('Media database record for 3D GLB created:', glbRecord.id);

  console.log('\n--- 3. Testing Media Querying, Search, and Filtering ---');
  const { data: userMedia, error: queryErr } = await supabase
    .from('media')
    .select('*')
    .eq('user_id', user.id);

  if (queryErr) throw queryErr;
  console.log(`Retrieved ${userMedia.length} media items from database for this user.`);

  // Test Favorite Toggle
  console.log('Testing Favorite Toggle for GLB record...');
  const { error: favErr } = await supabase
    .from('media')
    .update({ is_favorite: true })
    .eq('id', glbRecord.id);
  if (favErr) throw favErr;
  console.log('Favorite status updated successfully.');

  // Test Share Token Query (simulate public share link)
  console.log('Testing Share Token access...');
  const { data: sharedItem, error: shareErr } = await supabase
    .from('media')
    .select('*')
    .eq('share_token', glbRecord.share_token)
    .single();
  if (shareErr) throw shareErr;
  console.log(`Share token (${sharedItem.share_token}) verified successfully for "${sharedItem.title}".`);

  console.log('\n=== ALL SUPABASE INTEGRATION TESTS PASSED WITH 100% SUCCESS ===\n');
}

runTests().catch(err => {
  console.error('\n❌ TEST SUITE FAILED:', err);
  process.exit(1);
});
