import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

const GRADIENTS = [
  "linear-gradient(135deg,#7C5CFF,#3DD9EB)",
  "linear-gradient(135deg,#FFB454,#FF6B6B)",
  "linear-gradient(135deg,#3DD9EB,#4ADE80)",
  "linear-gradient(135deg,#A78BFA,#7C5CFF)",
  "linear-gradient(135deg,#FF9F6B,#FFB454)",
  "linear-gradient(135deg,#5CE1E6,#7C5CFF)",
];

export function guessMediaType(ext) {
  const e = (ext || '').toLowerCase().replace('.', '');
  if (['glb', 'gltf'].includes(e)) return '3d';
  if (e === 'gif') return 'gif';
  if (['mp4', 'webm', 'mov', 'm4v', 'ogg'].includes(e)) return 'video';
  return 'image';
}

function formatMediaRecord(row, index = 0) {
  const sizeMB = row.file_size ? Number(row.file_size) / (1024 * 1024) : (row.sizeMB || 0);
  const ext = (row.file_name || '').split('.').pop().toUpperCase();
  
  return {
    id: row.id,
    name: row.title || row.file_name,
    title: row.title || row.file_name,
    description: row.description || '',
    tags: row.tags || [],
    type: row.file_type || 'image',
    fileName: row.file_name,
    filePath: row.file_path,
    url: row.file_url || '',
    sizeMB: sizeMB,
    fileSize: row.file_size,
    mimeType: row.mime_type,
    views: Number(row.views || 0),
    date: new Date(row.created_at || Date.now()),
    favorite: Boolean(row.is_favorite),
    public: Boolean(row.is_public),
    shared: Boolean(row.is_shared),
    shareToken: row.share_token,
    gradient: GRADIENTS[(typeof row.id === 'string' ? row.id.charCodeAt(0) : (index || 0)) % GRADIENTS.length],
    dims: row.width && row.height ? `${row.width} × ${row.height}` : (row.file_type === 'video' ? '1920 × 1080' : row.file_type === 'gif' ? '600 × 400' : '—'),
    duration: row.duration || null,
    format: ext || (row.file_type === '3d' ? 'GLB' : row.file_type === 'gif' ? 'GIF' : 'MP4'),
    userId: row.user_id,
  };
}

export const mediaService = {
  // Fetch media items for user or public
  async fetchMediaList({ userId, search = '', typeFilter = 'all', sortBy = 'newest', isFavorite = null, isPublic = null }) {
    if (!isSupabaseConfigured()) {
      return [];
    }

    let query = supabase.from('media').select('*');

    if (userId) {
      query = query.eq('user_id', userId);
    }

    if (isFavorite !== null) {
      query = query.eq('is_favorite', isFavorite);
    }

    if (isPublic !== null) {
      query = query.eq('is_public', isPublic);
    }

    if (typeFilter && typeFilter !== 'all') {
      query = query.eq('file_type', typeFilter);
    }

    if (search && search.trim()) {
      query = query.or(`title.ilike.%${search.trim()}%,file_name.ilike.%${search.trim()}%,description.ilike.%${search.trim()}%`);
    }

    // Sort order
    if (sortBy === 'newest') query = query.order('created_at', { ascending: false });
    else if (sortBy === 'oldest') query = query.order('created_at', { ascending: true });
    else if (sortBy === 'largest') query = query.order('file_size', { ascending: false });
    else if (sortBy === 'smallest') query = query.order('file_size', { ascending: true });
    else query = query.order('created_at', { ascending: false });

    const { data, error } = await query;
    if (error) {
      console.error("Error fetching media from Supabase:", error);
      throw error;
    }

    return (data || []).map((row, idx) => formatMediaRecord(row, idx));
  },

  // Upload file to Supabase Storage and create database record
  async uploadMedia({ file, userId, title, description = '', tags = [], isPublic = true, onProgress }) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured. Please add your credentials in .env");
    }

    if (!userId) {
      throw new Error("You must be logged in to upload media.");
    }

    const fileExt = file.name.split('.').pop().toLowerCase();
    const mediaType = guessMediaType(fileExt);
    const fileId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15);
    const sanitizedFileName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const storagePath = `users/${userId}/${fileId}/${sanitizedFileName}`;

    if (onProgress) onProgress(20);

    // 1. Upload to Supabase Storage bucket 'media'
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('media')
      .upload(storagePath, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type || 'application/octet-stream',
      });

    if (uploadError) {
      console.error("Storage upload error:", uploadError);
      throw new Error(`Storage upload failed: ${uploadError.message}`);
    }

    if (onProgress) onProgress(70);

    // 2. Get Public URL
    const { data: { publicUrl } } = supabase.storage
      .from('media')
      .getPublicUrl(storagePath);

    // 3. Create database row in public.media
    const recordPayload = {
      user_id: userId,
      file_name: file.name,
      file_path: storagePath,
      file_url: publicUrl,
      file_type: mediaType,
      mime_type: file.type || 'application/octet-stream',
      file_size: file.size,
      title: title || file.name,
      description: description,
      tags: tags,
      is_public: isPublic,
      is_favorite: false,
      is_shared: isPublic,
      views: 0,
      duration: mediaType === 'video' ? '0:30' : null,
    };

    const { data: insertedData, error: dbError } = await supabase
      .from('media')
      .insert(recordPayload)
      .select()
      .single();

    if (dbError) {
      console.error("Database insert error:", dbError);
      // Attempt cleanup from storage if DB fails
      await supabase.storage.from('media').remove([storagePath]);
      throw new Error(`Database record creation failed: ${dbError.message}`);
    }

    if (onProgress) onProgress(100);

    return formatMediaRecord(insertedData);
  },

  // Toggle Favorite
  async toggleFavorite(mediaId, nextFavStatus) {
    if (!isSupabaseConfigured()) return;

    const { error } = await supabase
      .from('media')
      .update({ is_favorite: nextFavStatus, updated_at: new Date().toISOString() })
      .eq('id', mediaId);

    if (error) throw error;
  },

  // Toggle Public / Private visibility
  async toggleVisibility(mediaId, nextPublicStatus) {
    if (!isSupabaseConfigured()) return;

    const { error } = await supabase
      .from('media')
      .update({ is_public: nextPublicStatus, is_shared: nextPublicStatus, updated_at: new Date().toISOString() })
      .eq('id', mediaId);

    if (error) throw error;
  },

  // Update Media Details
  async updateMedia(mediaId, updates) {
    if (!isSupabaseConfigured()) return;

    const { data, error } = await supabase
      .from('media')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', mediaId)
      .select()
      .single();

    if (error) throw error;
    return formatMediaRecord(data);
  },

  // Delete Media (from both Storage and Database)
  async deleteMedia(mediaId, filePath) {
    if (!isSupabaseConfigured()) return;

    // 1. Delete from database
    const { error: dbError } = await supabase
      .from('media')
      .delete()
      .eq('id', mediaId);

    if (dbError) throw dbError;

    // 2. Delete from storage if filePath exists
    if (filePath) {
      const { error: storageError } = await supabase.storage
        .from('media')
        .remove([filePath]);
      if (storageError) {
        console.warn("Could not remove file from storage:", storageError.message);
      }
    }
  },

  // Fetch Media by Share Token (for public sharing & embeds)
  async fetchByShareToken(shareToken) {
    if (!isSupabaseConfigured() || !shareToken) return null;

    const { data, error } = await supabase
      .from('media')
      .select('*, profiles(full_name, email)')
      .eq('share_token', shareToken)
      .single();

    if (error || !data) return null;

    // Increment view count asynchronously
    supabase.rpc('increment_media_views', { media_id: data.id }).catch(() => {});

    return formatMediaRecord(data);
  },

  // Aggregate user statistics for Dashboard
  async getUserStats(userId) {
    if (!isSupabaseConfigured() || !userId) {
      return {
        totalUploads: 0,
        totalViews: 0,
        totalSizeMB: 0,
        sharedCount: 0,
        typeBreakdown: { '3d': 0, gif: 0, video: 0, image: 0 },
      };
    }

    const { data, error } = await supabase
      .from('media')
      .select('file_size, views, is_public, file_type')
      .eq('user_id', userId);

    if (error || !data) {
      return {
        totalUploads: 0,
        totalViews: 0,
        totalSizeMB: 0,
        sharedCount: 0,
        typeBreakdown: { '3d': 0, gif: 0, video: 0, image: 0 },
      };
    }

    let totalViews = 0;
    let totalBytes = 0;
    let sharedCount = 0;
    const typeBreakdown = { '3d': 0, gif: 0, video: 0, image: 0 };

    data.forEach((row) => {
      totalViews += Number(row.views || 0);
      totalBytes += Number(row.file_size || 0);
      if (row.is_public) sharedCount++;
      const t = row.file_type || 'image';
      typeBreakdown[t] = (typeBreakdown[t] || 0) + (Number(row.file_size || 0) / (1024 * 1024));
    });

    return {
      totalUploads: data.length,
      totalViews,
      totalSizeMB: totalBytes / (1024 * 1024),
      sharedCount,
      typeBreakdown,
    };
  },
};
