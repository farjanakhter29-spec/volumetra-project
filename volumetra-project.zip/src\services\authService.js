import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

// Helper to format raw Supabase Auth errors into user-friendly error objects
export function parseAuthError(error) {
  if (!error) return { message: "An unknown authentication error occurred.", isRateLimit: false };

  const msg = (error.message || '').toLowerCase();
  const status = error.status || error.statusCode;

  // Supabase 429 Rate Limit (default SMTP limit is ~3-4 emails/hour per project)
  if (
    status === 429 ||
    error.code === 'over_email_send_rate_limit' ||
    msg.includes('rate limit') ||
    msg.includes('over_email_send_rate_limit') ||
    msg.includes('too many requests')
  ) {
    return {
      message: "Email rate limit exceeded by Supabase's default mailer (3-4 emails/hr limit). Please wait a few minutes before trying again or configure Custom SMTP in your Supabase dashboard.",
      isRateLimit: true,
      code: 'RATE_LIMIT',
    };
  }

  // Email not confirmed
  if (msg.includes('email not confirmed') || error.code === 'email_not_confirmed') {
    return {
      message: "Your email has not been verified yet. Please check your inbox for the confirmation link, or click 'Resend Confirmation'.",
      isUnconfirmed: true,
      code: 'EMAIL_NOT_CONFIRMED',
    };
  }

  // User already registered
  if (msg.includes('user already registered') || msg.includes('already exists')) {
    return {
      message: "An account with this email address already exists. Please log in instead.",
      isUserExists: true,
      code: 'USER_EXISTS',
    };
  }

  // Invalid login credentials
  if (msg.includes('invalid login credentials') || msg.includes('invalid credentials')) {
    return {
      message: "Invalid email or password. Please double-check your credentials.",
      code: 'INVALID_CREDENTIALS',
    };
  }

  // Invalid email format / rejected domain
  if (msg.includes('invalid') && msg.includes('email')) {
    return {
      message: "Please enter a valid email address (e.g. yourname@domain.com).",
      code: 'INVALID_EMAIL',
    };
  }

  // Password requirements
  if (msg.includes('password') && (msg.includes('short') || msg.includes('least 6'))) {
    return {
      message: "Password must be at least 6 characters long.",
      code: 'PASSWORD_TOO_SHORT',
    };
  }

  return {
    message: error.message || "Authentication failed. Please try again.",
    code: error.code || 'AUTH_ERROR',
  };
}

export const authService = {
  // Sign up with Email and Password
  async signUp(email, password, fullName) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured. Please add your VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in .env");
    }

    const { data, error } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
      options: {
        data: {
          full_name: fullName.trim(),
          role: 'user',
        },
      },
    });

    if (error) {
      const parsed = parseAuthError(error);
      const err = new Error(parsed.message);
      err.meta = parsed;
      throw err;
    }

    return data;
  },

  // Sign in with Email and Password
  async signIn(email, password) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured. Please add your VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in .env");
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });

    if (error) {
      const parsed = parseAuthError(error);
      const err = new Error(parsed.message);
      err.meta = parsed;
      throw err;
    }

    return data;
  },

  // Resend confirmation email with rate-limit protection
  async resendVerificationEmail(email) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured.");
    }

    const { data, error } = await supabase.auth.resend({
      type: 'signup',
      email: email.trim().toLowerCase(),
    });

    if (error) {
      const parsed = parseAuthError(error);
      const err = new Error(parsed.message);
      err.meta = parsed;
      throw err;
    }

    return data;
  },

  // Sign out
  async signOut() {
    if (!isSupabaseConfigured()) return;
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  // Send password reset email
  async resetPassword(email) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured. Please add your VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in .env");
    }

    const { data, error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });

    if (error) {
      const parsed = parseAuthError(error);
      const err = new Error(parsed.message);
      err.meta = parsed;
      throw err;
    }

    return data;
  },

  // Update password (for authenticated user or reset session)
  async updatePassword(newPassword) {
    if (!isSupabaseConfigured()) {
      throw new Error("Supabase is not configured.");
    }

    const { data, error } = await supabase.auth.updateUser({
      password: newPassword,
    });

    if (error) {
      const parsed = parseAuthError(error);
      const err = new Error(parsed.message);
      err.meta = parsed;
      throw err;
    }

    return data;
  },

  // Get current active session & user
  async getCurrentSession() {
    if (!isSupabaseConfigured()) return null;

    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session) return null;
    return session;
  },

  // Get user profile from public.profiles
  async getUserProfile(userId) {
    if (!isSupabaseConfigured() || !userId) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      console.warn("Could not fetch user profile:", error.message);
      return null;
    }
    return data;
  },

  // Update user profile in public.profiles
  async updateUserProfile(userId, updates) {
    if (!isSupabaseConfigured() || !userId) {
      throw new Error("Supabase is not configured.");
    }

    const { data, error } = await supabase
      .from('profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Listen to Auth State Changes
  onAuthStateChange(callback) {
    if (!isSupabaseConfigured()) {
      return { data: { subscription: { unsubscribe: () => {} } } };
    }

    return supabase.auth.onAuthStateChange(callback);
  },
};
