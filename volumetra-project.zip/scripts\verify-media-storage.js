import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';

// Read .env
const envPath = path.resolve('.env');
const envContent = fs.readFileSync(envPath, 'utf8');
const envVars = {};
envContent.split('\n').forEach(line => {
  const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
  if (match) {
    let value = match[2] || '';
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    if (value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1);
    envVars[match[1]] = value.trim();
  }
});

const supabaseUrl = envVars.VITE_SUPABASE_URL;
const supabaseAnonKey = envVars.VITE_SUPABASE_PUBLISHABLE_KEY || envVars.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

function createMinimalGLB() {
  const jsonHeader = JSON.stringify({
    asset: { version: "2.0", generator: "Volumetra Test Generator" },
    scene: 0,
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0 }],
    meshes: [{ primitives: [{ attributes: {} }] }]
  });
  const jsonPadding = (4 - (jsonHeader.length % 4)) % 4;
  const paddedJson = jsonHeader + " ".repeat(jsonPadding);
  const jsonBuffer = Buffer.from(paddedJson, "utf8");

  const totalLength = 12 + 8 + jsonBuffer.length;
  const glb = Buffer.alloc(totalLength);

  // Header: magic (0x46546C67 "glTF"), version (2), length
  glb.writeUInt32LE(0x46546C67, 0);
  glb.writeUInt32LE(2, 4);
  glb.writeUInt32LE(totalLength, 8);

  // Chunk 0: JSON
  glb.writeUInt32LE(jsonBuffer.length, 12);
  glb.writeUInt32LE(0x4E4F534A, 16); // "JSON"
  jsonBuffer.copy(glb, 20);

  return glb;
}

function createMinimalPNG() {
  return Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    'base64'
  );
}

async function verifyStorageAndMedia() {
  console.log('--- Fetching Existing Profile from DB ---');
  const { data: profiles, error: pErr } = await supabase.from('profiles').select('*').limit(1);
  if (pErr || !profiles || profiles.length === 0) {
    throw new Error('No profile found to attach test media to.');
  }

  const userId = profiles[0].id;
  console.log('Using Profile ID:', userId, `(${profiles[0].email})`);

  console.log('\n--- Testing Storage Uploads ---');

  // 1. Upload Test Image
  const imgBuffer = createMinimalPNG();
  const imgFileId = `img_${Date.now()}`;
  const imgPath = `users/${userId}/${imgFileId}/render_preview.png`;

  console.log(`Uploading test image: ${imgPath}`);
  const { data: imgUpload, error: imgUploadErr } = await supabase.storage
    .from('media')
    .upload(imgPath, imgBuffer, {
      contentType: 'image/png',
      upsert: true
    });

  if (imgUploadErr) {
    console.error('Storage Upload Error (Image):', imgUploadErr.message);
  } else {
    console.log('Image uploaded to Supabase Storage bucket "media" successfully.');
  }

  const { data: { publicUrl: imgUrl } } = supabase.storage.from('media').getPublicUrl(imgPath);
  console.log('Image Public URL:', imgUrl);

  // 2. Upload Test 3D GLB
  const glbBuffer = createMinimalGLB();
  const glbFileId = `glb_${Date.now()}`;
  const glbPath = `users/${userId}/${glbFileId}/sci_fi_helmet.glb`;

  console.log(`Uploading test GLB: ${glbPath}`);
  const { data: glbUpload, error: glbUploadErr } = await supabase.storage
    .from('media')
    .upload(glbPath, glbBuffer, {
      contentType: 'model/gltf-binary',
      upsert: true
    });

  if (glbUploadErr) {
    console.error('Storage Upload Error (GLB):', glbUploadErr.message);
  } else {
    console.log('3D GLB uploaded to Supabase Storage bucket "media" successfully.');
  }

  const { data: { publicUrl: glbUrl } } = supabase.storage.from('media').getPublicUrl(glbPath);
  console.log('3D GLB Public URL:', glbUrl);

  console.log('\n--- Testing Database Insertion into public.media ---');

  const { data: insertedRows, error: insertErr } = await supabase
    .from('media')
    .insert([
      {
        user_id: userId,
        file_name: 'render_preview.png',
        file_path: imgPath,
        file_url: imgUrl,
        file_type: 'image',
        mime_type: 'image/png',
        file_size: imgBuffer.length,
        title: 'Cyberpunk Concept Render',
        description: 'Volumetra test render asset',
        is_public: true,
        is_favorite: true,
        views: 12
      },
      {
        user_id: userId,
        file_name: 'sci_fi_helmet.glb',
        file_path: glbPath,
        file_url: glbUrl,
        file_type: '3d',
        mime_type: 'model/gltf-binary',
        file_size: glbBuffer.length,
        title: 'Sci-Fi Combat Helmet 3D Model',
        description: 'Real GLB model rendered in WebGL Three.js',
        is_public: true,
        is_favorite: false,
        views: 45
      }
    ])
    .select();

  if (insertErr) {
    console.error('Database Insert Error:', insertErr.message);
    throw insertErr;
  }

  console.log(`Successfully inserted ${insertedRows.length} media records into public.media:`);
  insertedRows.forEach(row => {
    console.log(` - [${row.file_type.toUpperCase()}] ${row.title} (ID: ${row.id}, Share Token: ${row.share_token})`);
  });

  console.log('\n--- Verifying Querying from Media Table ---');
  const { data: allMedia, error: qErr } = await supabase.from('media').select('*');
  if (qErr) throw qErr;
  console.log(`Total records in public.media: ${allMedia.length}`);

  console.log('\n🎉 ALL REAL SUPABASE STORAGE AND DATABASE OPERATIONS VERIFIED SUCCESSFULLY! 🎉\n');
}

verifyStorageAndMedia().catch(err => {
  console.error('Verification failed:', err);
  process.exit(1);
});
