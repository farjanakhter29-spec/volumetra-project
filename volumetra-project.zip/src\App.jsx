import React, { useState, useEffect, useRef, useMemo, useCallback, createContext, useContext } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import {
  Upload, Grid3x3, List, Search, SlidersHorizontal, Star, FolderOpen, Share2,
  Settings, LayoutDashboard, Users, LogOut, Sun, Moon, Menu, X, Plus,
  Image as ImageIcon, Film, Box, Play, Pause, Volume2, VolumeX, Maximize2,
  RotateCcw, ZoomIn, ZoomOut, Download, Trash2, Copy, Link2, Lock, Globe,
  QrCode, Code2, MoreVertical, Eye, Clock, HardDrive, CheckCircle2, AlertCircle,
  ChevronRight, ChevronDown, ArrowLeft, Sparkles, Layers, Shield, TrendingUp,
  UserCircle2, Mail, KeyRound, ArrowUpRight, Trash, Ban, FileWarning, Loader2,
  RefreshCw, Move, Camera, Heart, ChevronLeft, UploadCloud, FolderClosed,
  MousePointer2, PauseCircle, Check, ExternalLink, Info
} from "lucide-react";

import { isSupabaseConfigured } from "./lib/supabaseClient";
import { authService } from "./services/authService";
import { mediaService, guessMediaType } from "./services/mediaService";
import { adminService } from "./services/adminService";
import { QRCodeSVG } from "./components/QRCodeSVG";

/* ============================================================================
   FONTS + GLOBAL STYLE INJECTION
============================================================================ */
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

    :root{
      --bg: #0A0C12;
      --bg-elev: #101320;
      --bg-elev-2: #161A2B;
      --panel: rgba(22,26,43,0.65);
      --border: rgba(255,255,255,0.08);
      --border-strong: rgba(255,255,255,0.14);
      --text: #EDEFF7;
      --text-dim: #9297AE;
      --text-faint: #666C85;
      --violet: #7C5CFF;
      --violet-soft: rgba(124,92,255,0.14);
      --cyan: #3DD9EB;
      --amber: #FFB454;
      --danger: #FF6B6B;
      --success: #4ADE80;
      --radius: 16px;
    }
    html[data-theme='light']{
      --bg: #F3F4F9;
      --bg-elev: #FFFFFF;
      --bg-elev-2: #F7F8FC;
      --panel: rgba(255,255,255,0.72);
      --border: rgba(20,22,40,0.08);
      --border-strong: rgba(20,22,40,0.14);
      --text: #14162A;
      --text-dim: #5B5F78;
      --text-faint: #9599AD;
      --violet: #6B46F5;
      --violet-soft: rgba(107,70,245,0.10);
      --cyan: #0EA5B7;
      --amber: #C97A16;
      --danger: #DC3E3E;
      --success: #1E9E5A;
    }
    * { box-sizing: border-box; }
    .tmp-root { font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; background: var(--bg); color: var(--text); min-height:100vh; transition: background .35s ease, color .35s ease; }
    .tmp-root, .tmp-root * { scrollbar-width: thin; scrollbar-color: var(--border-strong) transparent; }
    .tmp-root ::-webkit-scrollbar{ width:8px; height:8px; }
    .tmp-root ::-webkit-scrollbar-thumb{ background: var(--border-strong); border-radius:8px; }
    .f-display { font-family: 'Space Grotesk', 'Inter', sans-serif; }
    .f-mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
    .glass { background: var(--panel); backdrop-filter: blur(20px) saturate(140%); -webkit-backdrop-filter: blur(20px) saturate(140%); border: 1px solid var(--border); }
    .grad-text { background: linear-gradient(100deg, var(--text) 20%, var(--violet) 55%, var(--cyan) 85%); -webkit-background-clip: text; background-clip:text; color: transparent; }
    .btn-primary { background: linear-gradient(135deg, var(--violet), #A78BFA); color: #fff; border: none; }
    .btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); box-shadow: 0 8px 24px -8px var(--violet-soft), 0 0 0 4px var(--violet-soft); }
    .btn-ghost { background: transparent; border: 1px solid var(--border-strong); color: var(--text); }
    .btn-ghost:hover { background: var(--bg-elev-2); }
    .card-hover { transition: transform .28s cubic-bezier(.2,.8,.2,1), box-shadow .28s ease, border-color .28s ease; }
    .card-hover:hover { transform: translateY(-4px); border-color: var(--border-strong); box-shadow: 0 20px 40px -20px rgba(0,0,0,0.5); }
    @keyframes floaty { 0%,100%{ transform: translateY(0px) rotate(0deg);} 50%{ transform: translateY(-14px) rotate(2deg);} }
    .floaty { animation: floaty 6s ease-in-out infinite; }
    .floaty-slow { animation: floaty 8.5s ease-in-out infinite; }
    @keyframes fadeUp { from { opacity:0; transform: translateY(16px);} to { opacity:1; transform:translateY(0);} }
    .fade-up { animation: fadeUp .7s cubic-bezier(.2,.7,.2,1) both; }
    @keyframes shimmer { 0%{ background-position: -400px 0;} 100%{ background-position: 400px 0;} }
    .skeleton { background: linear-gradient(90deg, var(--bg-elev-2) 0%, var(--border-strong) 50%, var(--bg-elev-2) 100%); background-size: 800px 100%; animation: shimmer 1.6s linear infinite; }
    @keyframes pulseRing { 0%{ box-shadow: 0 0 0 0 var(--violet-soft);} 100%{ box-shadow: 0 0 0 10px rgba(0,0,0,0);} }
    .focus-ring:focus-visible { outline: 2px solid var(--violet); outline-offset: 2px; }
    input, textarea, select, button { font-family: inherit; }
    .scroll-hide::-webkit-scrollbar{ display:none; }
    .scroll-hide { -ms-overflow-style:none; scrollbar-width:none; }
    @media (prefers-reduced-motion: reduce){
      .floaty, .floaty-slow, .fade-up, .skeleton { animation: none !important; }
    }
  `}</style>
);

const TYPE_META = {
  "3d": { label: "3D Image", icon: Box, color: "var(--violet)", exts: ["GLB", "GLTF"] },
  gif: { label: "GIF", icon: Film, color: "var(--amber)", exts: ["GIF"] },
  video: { label: "Video", icon: Play, color: "var(--cyan)", exts: ["MP4", "WEBM", "MOV"] },
  image: { label: "Image", icon: ImageIcon, color: "var(--success)", exts: ["JPG", "PNG", "WEBP"] },
};

const STORAGE_TOTAL_GB = 10;

/* ============================================================================
   CONTEXTS
============================================================================ */
const ThemeContext = createContext(null);
const ToastContext = createContext(null);

function useToast() { return useContext(ToastContext); }

/* ============================================================================
   TOASTS
============================================================================ */
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg, variant = "success") => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, msg, variant }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3600);
  }, []);
  return (
    <ToastContext.Provider value={push}>
      {children}
      <div style={{ position: "fixed", bottom: 20, right: 20, zIndex: 999, display: "flex", flexDirection: "column", gap: 10 }}>
        {toasts.map((t) => (
          <div key={t.id} className="glass fade-up" style={{
            display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", borderRadius: 12,
            minWidth: 260, maxWidth: 400, boxShadow: "0 12px 32px -12px rgba(0,0,0,0.5)",
            borderLeft: `3px solid ${t.variant === "error" ? "var(--danger)" : t.variant === "info" ? "var(--cyan)" : "var(--success)"}`
          }}>
            {t.variant === "error" ? <AlertCircle size={18} color="var(--danger)" /> : <CheckCircle2 size={18} color="var(--success)" />}
            <span style={{ fontSize: 13.5 }}>{t.msg}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

/* ============================================================================
   SMALL UI PRIMITIVES
============================================================================ */
function Button({ children, variant = "primary", size = "md", icon: Icon, onClick, style, disabled, full, type = "button" }) {
  const pad = size === "sm" ? "8px 14px" : size === "lg" ? "14px 26px" : "11px 18px";
  const fs = size === "sm" ? 13 : size === "lg" ? 15.5 : 14;
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
    padding: pad, fontSize: fs, fontWeight: 600, borderRadius: 12, cursor: disabled ? "not-allowed" : "pointer",
    transition: "all .2s ease", width: full ? "100%" : "auto", opacity: disabled ? 0.55 : 1,
    whiteSpace: "nowrap",
  };
  const cls = variant === "primary" ? "btn-primary" : variant === "ghost" ? "btn-ghost" : "";
  const extra = variant === "danger" ? { background: "rgba(255,107,107,0.12)", color: "var(--danger)", border: "1px solid rgba(255,107,107,0.3)" }
    : variant === "subtle" ? { background: "var(--bg-elev-2)", color: "var(--text)", border: "1px solid var(--border)" } : {};
  return (
    <button type={type} disabled={disabled} onClick={onClick} className={`${cls} focus-ring`} style={{ ...base, ...extra, ...style }}>
      {Icon && <Icon size={size === "sm" ? 15 : 17} />}
      {children}
    </button>
  );
}

function IconButton({ icon: Icon, onClick, label, active, size = 34 }) {
  return (
    <button aria-label={label} title={label} onClick={onClick} className="focus-ring" style={{
      width: size, height: size, display: "grid", placeItems: "center", borderRadius: 10,
      border: `1px solid ${active ? "var(--violet)" : "var(--border)"}`,
      background: active ? "var(--violet-soft)" : "var(--bg-elev-2)", color: active ? "var(--violet)" : "var(--text)",
      cursor: "pointer", transition: "all .18s ease",
    }}>
      <Icon size={size * 0.5} />
    </button>
  );
}

function Badge({ children, tone = "violet" }) {
  const tones = {
    violet: { bg: "var(--violet-soft)", color: "var(--violet)" },
    cyan: { bg: "rgba(61,217,235,0.14)", color: "var(--cyan)" },
    amber: { bg: "rgba(255,180,84,0.14)", color: "var(--amber)" },
    success: { bg: "rgba(74,222,128,0.14)", color: "var(--success)" },
    danger: { bg: "rgba(255,107,107,0.14)", color: "var(--danger)" },
    neutral: { bg: "var(--bg-elev-2)", color: "var(--text-dim)" },
  };
  const t = tones[tone] || tones.neutral;
  return <span style={{ background: t.bg, color: t.color, fontSize: 11.5, fontWeight: 700, padding: "3px 9px", borderRadius: 999, letterSpacing: .3 }}>{children}</span>;
}

function Modal({ open, onClose, title, children, width = 480 }) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(4,5,10,0.6)", backdropFilter: "blur(4px)",
      display: "grid", placeItems: "center", zIndex: 200, padding: 16,
    }}>
      <div onClick={(e) => e.stopPropagation()} className="glass fade-up" style={{
        width: "100%", maxWidth: width, borderRadius: 20, padding: 24, maxHeight: "88vh", overflowY: "auto",
        boxShadow: "0 30px 80px -20px rgba(0,0,0,0.6)", background: "var(--bg-elev)",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <h3 className="f-display" style={{ fontSize: 19, fontWeight: 700, margin: 0 }}>{title}</h3>
          <IconButton icon={X} onClick={onClose} label="Close" />
        </div>
        {children}
      </div>
    </div>
  );
}

function ConfirmDialog({ open, onClose, onConfirm, title, message, danger }) {
  return (
    <Modal open={open} onClose={onClose} title={title} width={400}>
      <p style={{ color: "var(--text-dim)", fontSize: 14.5, lineHeight: 1.6, margin: "0 0 22px" }}>{message}</p>
      <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button variant={danger ? "danger" : "primary"} onClick={() => { onConfirm(); onClose(); }}>
          {danger ? "Delete" : "Confirm"}
        </Button>
      </div>
    </Modal>
  );
}

function EmptyState({ icon: Icon = FolderOpen, title, message, action }) {
  return (
    <div className="fade-up" style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: "70px 20px", color: "var(--text-dim)" }}>
      <div style={{ width: 64, height: 64, borderRadius: 18, display: "grid", placeItems: "center", background: "var(--violet-soft)", marginBottom: 18 }}>
        <Icon size={28} color="var(--violet)" />
      </div>
      <h4 className="f-display" style={{ fontSize: 18, color: "var(--text)", margin: "0 0 8px" }}>{title}</h4>
      <p style={{ fontSize: 14, maxWidth: 360, margin: "0 0 20px", lineHeight: 1.6 }}>{message}</p>
      {action}
    </div>
  );
}

function CardSkeleton() {
  return <div className="skeleton" style={{ borderRadius: 16, aspectRatio: "4/3", border: "1px solid var(--border)" }} />;
}

function fmtSize(mb) { return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`; }
function fmtDate(d) { return new Date(d).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }); }
function timeAgo(d) {
  const dateObj = new Date(d);
  const s = Math.floor((Date.now() - dateObj.getTime()) / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60); if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60); if (h < 24) return `${h}h ago`;
  const days = Math.floor(h / 24); if (days < 30) return `${days}d ago`;
  return fmtDate(dateObj);
}

/* ============================================================================
   3D VIEWER: Supports Real GLB/GLTF from Supabase Storage + Procedural Fallback
   Uses pure Three.js manual orbital controls (drag rotate, shift-drag pan, scroll zoom)
============================================================================ */
function Model3DViewer({ modelUrl, seed = 1, height = 420 }) {
  const mountRef = useRef(null);
  const stateRef = useRef({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    let width = mount.clientWidth || 400, height2 = mount.clientHeight || 420;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height2, 0.1, 100);
    const baseDist = 6.5;
    camera.position.set(0, 0, baseDist);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height2);
    mount.innerHTML = "";
    mount.appendChild(renderer.domElement);

    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(4, 5, 6);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x7c5cff, 1.0);
    fill.position.set(-5, -3, 2);
    scene.add(fill);
    const cyanLight = new THREE.DirectionalLight(0x3dd9eb, 0.8);
    cyanLight.position.set(0, -5, -4);
    scene.add(cyanLight);
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));

    const group = new THREE.Group();
    scene.add(group);

    // Ground reflection ring
    const ringGeo = new THREE.RingGeometry(2.1, 2.6, 64);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x7c5cff, transparent: true, opacity: 0.12, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -1.9;
    scene.add(ring);

    setLoading(true);
    setLoadError(null);

    // If a real 3D model URL is provided from Supabase Storage, load with GLTFLoader
    if (modelUrl && (modelUrl.endsWith('.glb') || modelUrl.endsWith('.gltf') || modelUrl.includes('/media/'))) {
      const loader = new GLTFLoader();
      loader.load(
        modelUrl,
        (gltf) => {
          const model = gltf.scene;
          // Center and auto-scale model to fit unit bounds
          const box = new THREE.Box3().setFromObject(model);
          const center = box.getCenter(new THREE.Vector3());
          const size = box.getSize(new THREE.Vector3());
          const maxDim = Math.max(size.x, size.y, size.z) || 1;
          const scale = 2.8 / maxDim;
          model.scale.setScalar(scale);
          model.position.sub(center.multiplyScalar(scale));
          group.add(model);
          setLoading(false);
        },
        undefined,
        (err) => {
          console.warn("Could not load external GLTF/GLB from URL, using fallback procedural model:", err);
          loadProceduralModel();
        }
      );
    } else {
      loadProceduralModel();
    }

    function loadProceduralModel() {
      const geoPool = [
        new THREE.TorusKnotGeometry(1.15, 0.38, 160, 24),
        new THREE.IcosahedronGeometry(1.5, 1),
        new THREE.OctahedronGeometry(1.6, 2),
        new THREE.DodecahedronGeometry(1.5, 0),
      ];
      const geo = geoPool[Math.abs(Number(seed) || 0) % geoPool.length];
      const mat = new THREE.MeshStandardMaterial({ color: 0x8b6bff, metalness: 0.35, roughness: 0.25 });
      const mesh = new THREE.Mesh(geo, mat);
      group.add(mesh);

      const wireGeo = new THREE.WireframeGeometry(geo);
      const wireMat = new THREE.LineBasicMaterial({ color: 0x3dd9eb, transparent: true, opacity: 0.35 });
      const wire = new THREE.LineSegments(wireGeo, wireMat);
      wire.scale.setScalar(1.01);
      group.add(wire);
      setLoading(false);
    }

    let dist = baseDist;
    let rotX = 0.3, rotY = 0.5;
    let dragging = false, lastX = 0, lastY = 0;
    let panX = 0, panY = 0;

    const applyCamera = () => {
      const x = dist * Math.sin(rotY) * Math.cos(rotX);
      const y = dist * Math.sin(rotX);
      const z = dist * Math.cos(rotY) * Math.cos(rotX);
      camera.position.set(x + panX, y + panY, z);
      camera.lookAt(panX, panY, 0);
    };
    applyCamera();

    const onDown = (e) => { dragging = true; const p = e.touches ? e.touches[0] : e; lastX = p.clientX; lastY = p.clientY; };
    const onMove = (e) => {
      if (!dragging) return;
      const p = e.touches ? e.touches[0] : e;
      const dx = p.clientX - lastX, dy = p.clientY - lastY;
      lastX = p.clientX; lastY = p.clientY;
      if (e.shiftKey) {
        panX -= dx * 0.004; panY += dy * 0.004;
      } else {
        rotY -= dx * 0.006;
        rotX = Math.max(-1.2, Math.min(1.2, rotX + dy * 0.006));
      }
      applyCamera();
    };
    const onUp = () => { dragging = false; };
    const onWheel = (e) => { e.preventDefault(); dist = Math.max(2.5, Math.min(16, dist + e.deltaY * 0.01)); applyCamera(); };

    const dom = renderer.domElement;
    dom.addEventListener("mousedown", onDown);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    dom.addEventListener("touchstart", onDown, { passive: true });
    dom.addEventListener("touchmove", onMove, { passive: true });
    dom.addEventListener("touchend", onUp);
    dom.addEventListener("wheel", onWheel, { passive: false });

    let raf;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (stateRef.current.autoRotate && !dragging) { rotY += 0.0035; applyCamera(); }
      group.rotation.y += 0.0012;
      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!mount) return;
      width = mount.clientWidth; height2 = mount.clientHeight;
      if (width && height2) {
        camera.aspect = width / height2;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height2);
      }
    };
    window.addEventListener("resize", onResize);
    const ro = new ResizeObserver(onResize);
    ro.observe(mount);

    stateRef.current = {
      reset: () => { dist = baseDist; rotX = 0.3; rotY = 0.5; panX = 0; panY = 0; applyCamera(); },
      zoomIn: () => { dist = Math.max(2.5, dist - 1); applyCamera(); },
      zoomOut: () => { dist = Math.min(16, dist + 1); applyCamera(); },
      autoRotate: true,
    };

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      ro.disconnect();
      dom.removeEventListener("wheel", onWheel);
      renderer.dispose();
      ringGeo.dispose(); ringMat.dispose();
      if (mount) mount.innerHTML = "";
    };
  }, [modelUrl, seed]);

  useEffect(() => { if (stateRef.current) stateRef.current.autoRotate = autoRotate; }, [autoRotate]);

  const ctrlBtn = (Icon, onClick, label, active) => (
    <button title={label} aria-label={label} onClick={onClick} className="focus-ring" style={{
      width: 38, height: 38, borderRadius: 10, display: "grid", placeItems: "center", cursor: "pointer",
      background: active ? "var(--violet)" : "rgba(10,12,18,0.55)", color: "#fff", border: "1px solid rgba(255,255,255,0.12)",
      backdropFilter: "blur(6px)",
    }}>
      <Icon size={17} />
    </button>
  );

  return (
    <div ref={wrapRef} style={{
      position: fullscreen ? "fixed" : "relative", inset: fullscreen ? 0 : "auto", zIndex: fullscreen ? 300 : 1,
      borderRadius: fullscreen ? 0 : 18, overflow: "hidden", height: fullscreen ? "100vh" : height,
      background: "radial-gradient(circle at 50% 30%, rgba(124,92,255,0.14), transparent 60%), var(--bg-elev-2)",
      border: fullscreen ? "none" : "1px solid var(--border)",
    }}>
      <div ref={mountRef} style={{ width: "100%", height: "100%", cursor: "grab" }} />
      {loading && (
        <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", background: "var(--bg-elev-2)" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
            <Loader2 size={26} className="f-mono" color="var(--violet)" style={{ animation: "spin 1s linear infinite" }} />
            <span style={{ fontSize: 12.5, color: "var(--text-dim)" }}>Loading 3D scene…</span>
          </div>
        </div>
      )}
      <div style={{ position: "absolute", top: 12, left: 12, display: "flex", gap: 6 }}>
        <span className="f-mono" style={{ fontSize: 10.5, background: "rgba(10,12,18,0.55)", color: "#fff", padding: "5px 9px", borderRadius: 8, display: "flex", alignItems: "center", gap: 5 }}>
          <MousePointer2 size={11} /> drag to rotate · shift+drag to pan · scroll to zoom
        </span>
      </div>
      <div style={{ position: "absolute", bottom: 12, right: 12, display: "flex", gap: 8 }}>
        {ctrlBtn(autoRotate ? PauseCircle : RotateCcw, () => setAutoRotate((a) => !a), "Toggle auto-rotate", autoRotate)}
        {ctrlBtn(ZoomIn, () => stateRef.current.zoomIn && stateRef.current.zoomIn(), "Zoom in")}
        {ctrlBtn(ZoomOut, () => stateRef.current.zoomOut && stateRef.current.zoomOut(), "Zoom out")}
        {ctrlBtn(RefreshCw, () => stateRef.current.reset && stateRef.current.reset(), "Reset camera")}
        {ctrlBtn(fullscreen ? X : Maximize2, () => setFullscreen((f) => !f), "Fullscreen")}
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

/* ============================================================================
   GIF PREVIEW + REAL VIDEO PLAYER
============================================================================ */
function GifPreview({ media, height = 320 }) {
  const [playing, setPlaying] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);

  return (
    <div style={{
      position: fullscreen ? "fixed" : "relative", inset: fullscreen ? 0 : "auto", zIndex: fullscreen ? 300 : 1,
      height: fullscreen ? "100vh" : height, borderRadius: fullscreen ? 0 : 18, overflow: "hidden",
      background: media.url ? "var(--bg-elev-2)" : media.gradient, display: "grid", placeItems: "center", border: "1px solid var(--border)",
    }}>
      {media.url ? (
        <img
          src={media.url}
          alt={media.name}
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />
      ) : (
        <>
          <div style={{ position: "absolute", inset: 0, background: playing ? "none" : "rgba(0,0,0,0.25)", transition: "background .3s" }} />
          <Film size={64} color="rgba(255,255,255,0.85)" style={{
            filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.3))",
            animation: playing ? "wiggle 1.8s ease-in-out infinite" : "none",
          }} />
        </>
      )}
      <style>{`@keyframes wiggle { 0%,100%{ transform: scale(1) rotate(0deg);} 50%{ transform: scale(1.08) rotate(-3deg);} }`}</style>
      <div style={{ position: "absolute", top: 12, left: 12 }}><Badge tone="amber">GIF · ANIMATED</Badge></div>
      <div style={{ position: "absolute", bottom: 12, left: 12, right: 12, display: "flex", justifyContent: "space-between" }}>
        <IconButton icon={playing ? Pause : Play} onClick={() => setPlaying((p) => !p)} label="Play/pause" />
        <IconButton icon={fullscreen ? X : Maximize2} onClick={() => setFullscreen((f) => !f)} label="Fullscreen" />
      </div>
    </div>
  );
}

function VideoPreview({ media, height = 320 }) {
  const videoRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);

  const togglePlay = () => {
    if (!videoRef.current) {
      setPlaying((p) => !p);
      return;
    }
    if (videoRef.current.paused) {
      videoRef.current.play();
      setPlaying(true);
    } else {
      videoRef.current.pause();
      setPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current && videoRef.current.duration) {
      setProgress((videoRef.current.currentTime / videoRef.current.duration) * 100);
    }
  };

  const handleSeek = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - r.left) / r.width;
    if (videoRef.current && videoRef.current.duration) {
      videoRef.current.currentTime = pct * videoRef.current.duration;
      setProgress(pct * 100);
    } else {
      setProgress(pct * 100);
    }
  };

  return (
    <div style={{
      position: fullscreen ? "fixed" : "relative", inset: fullscreen ? 0 : "auto", zIndex: fullscreen ? 300 : 1,
      height: fullscreen ? "100vh" : height, borderRadius: fullscreen ? 0 : 18, overflow: "hidden",
      background: "var(--bg-elev-2)", border: "1px solid var(--border)",
    }}>
      {media.url ? (
        <video
          ref={videoRef}
          src={media.url}
          muted={muted}
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setPlaying(false)}
          onClick={togglePlay}
          style={{ width: "100%", height: "100%", objectFit: "contain", cursor: "pointer" }}
        />
      ) : (
        <div onClick={togglePlay} style={{ position: "absolute", inset: 0, background: media.gradient, display: "grid", placeItems: "center", cursor: "pointer" }}>
          {!playing && (
            <div style={{ width: 68, height: 68, borderRadius: "50%", background: "rgba(0,0,0,0.4)", backdropFilter: "blur(6px)", display: "grid", placeItems: "center" }}>
              <Play size={28} color="#fff" fill="#fff" style={{ marginLeft: 3 }} />
            </div>
          )}
        </div>
      )}

      <div style={{ position: "absolute", top: 12, left: 12 }}><Badge tone="cyan">{media.format || "MP4"} · {media.duration || "0:30"}</Badge></div>
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "22px 14px 12px", background: "linear-gradient(to top, rgba(0,0,0,0.75), transparent)" }}>
        <div style={{ height: 4, background: "rgba(255,255,255,0.25)", borderRadius: 4, marginBottom: 10, cursor: "pointer" }} onClick={handleSeek}>
          <div style={{ height: "100%", width: `${progress}%`, background: "var(--cyan)", borderRadius: 4 }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <IconButton size={30} icon={playing ? Pause : Play} onClick={togglePlay} label="Play/pause" />
            <IconButton size={30} icon={muted ? VolumeX : Volume2} onClick={() => setMuted((m) => !m)} label="Mute" />
            <span className="f-mono" style={{ fontSize: 11.5, color: "#fff" }}>{media.duration || "0:30"}</span>
          </div>
          <IconButton size={30} icon={fullscreen ? X : Maximize2} onClick={() => setFullscreen((f) => !f)} label="Fullscreen" />
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   SUPABASE CONFIG NOTIFICATION BANNER
============================================================================ */
function ConfigBanner() {
  if (isSupabaseConfigured()) return null;

  return (
    <div style={{
      background: "linear-gradient(90deg, rgba(124,92,255,0.18), rgba(61,217,235,0.18))",
      borderBottom: "1px solid var(--border-strong)",
      padding: "10px 18px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      fontSize: 13,
      zIndex: 100,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <Sparkles size={16} color="var(--cyan)" />
        <span>
          <strong>Supabase credentials ready to connect:</strong> Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_PUBLISHABLE_KEY</code> in your <code>.env</code> file to enable permanent cloud storage.
        </span>
      </div>
    </div>
  );
}

/* ============================================================================
   NAV: PUBLIC NAVBAR
============================================================================ */
function Logo({ size = 26 }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
      <div style={{
        width: size, height: size, borderRadius: 8, background: "linear-gradient(135deg,var(--violet),var(--cyan))",
        display: "grid", placeItems: "center", boxShadow: "0 4px 14px -4px var(--violet-soft)",
      }}>
        <Box size={size * 0.6} color="#fff" strokeWidth={2.4} />
      </div>
      <span className="f-display" style={{ fontWeight: 700, fontSize: size * 0.72, letterSpacing: -0.3 }}>Volumetra</span>
    </div>
  );
}

function ThemeToggle() {
  const { theme, setTheme } = useContext(ThemeContext);
  return (
    <IconButton icon={theme === "dark" ? Sun : Moon} onClick={() => setTheme(theme === "dark" ? "light" : "dark")} label="Toggle theme" />
  );
}

function PublicNavbar({ go }) {
  const [open, setOpen] = useState(false);
  return (
    <header className="glass" style={{ position: "sticky", top: 0, zIndex: 100, padding: "14px 24px" }}>
      <div style={{ maxWidth: 1240, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ cursor: "pointer" }} onClick={() => go("landing")}><Logo /></div>
        <nav style={{ display: "flex", gap: 28, fontSize: 14, fontWeight: 500 }} className="hide-mobile">
          {["Product", "Library", "Pricing"].map((l) => (
            <a key={l} href="#" onClick={(e) => { e.preventDefault(); if (l === "Library") go("library"); }} style={{ color: "var(--text-dim)", textDecoration: "none" }}>{l}</a>
          ))}
        </nav>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <ThemeToggle />
          <span className="hide-mobile" style={{ display: "flex", gap: 10 }}>
            <Button variant="ghost" size="sm" onClick={() => go("login")}>Log in</Button>
            <Button size="sm" onClick={() => go("signup")}>Sign up free</Button>
          </span>
          <span className="show-mobile"><IconButton icon={open ? X : Menu} onClick={() => setOpen((o) => !o)} label="Menu" /></span>
        </div>
      </div>
      {open && (
        <div className="show-mobile fade-up" style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 10 }}>
          <Button variant="ghost" full onClick={() => go("login")}>Log in</Button>
          <Button full onClick={() => go("signup")}>Sign up free</Button>
        </div>
      )}
      <style>{`
        .hide-mobile { display: flex; }
        .show-mobile { display: none; }
        @media (max-width: 860px) { .hide-mobile { display: none; } .show-mobile { display: flex; } }
      `}</style>
    </header>
  );
}

/* ============================================================================
   LANDING PAGE
============================================================================ */
function FloatingCard({ style, gradient, icon: Icon, label, className }) {
  return (
    <div className={className} style={{
      position: "absolute", width: 120, padding: 14, borderRadius: 16, ...style,
    }}>
      <div className="glass card-hover" style={{ borderRadius: 16, padding: 12, boxShadow: "0 20px 50px -20px rgba(0,0,0,0.55)" }}>
        <div style={{ width: "100%", aspectRatio: "1/1", borderRadius: 10, background: gradient, display: "grid", placeItems: "center", marginBottom: 8 }}>
          <Icon size={22} color="#fff" />
        </div>
        <span style={{ fontSize: 11, fontWeight: 600, color: "var(--text-dim)" }}>{label}</span>
      </div>
    </div>
  );
}

function Hero({ go }) {
  return (
    <section style={{ maxWidth: 1240, margin: "0 auto", padding: "72px 24px 40px", display: "grid", gridTemplateColumns: "1.05fr 0.95fr", gap: 50, alignItems: "center" }} className="hero-grid">
      <div className="fade-up">
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", borderRadius: 999, border: "1px solid var(--border-strong)", fontSize: 12.5, color: "var(--text-dim)", marginBottom: 22 }}>
          <Sparkles size={13} color="var(--violet)" /> Built for creators of dimensional media
        </div>
        <h1 className="f-display" style={{ fontSize: "clamp(38px, 5.2vw, 64px)", lineHeight: 1.04, fontWeight: 700, margin: "0 0 20px", letterSpacing: -1.2 }}>
          Upload. Create.<br /><span className="grad-text">Share.</span>
        </h1>
        <p style={{ fontSize: 17, lineHeight: 1.65, color: "var(--text-dim)", maxWidth: 480, margin: "0 0 32px" }}>
          A home for your 3D images, GIFs, and short videos — drag in a file, get an interactive viewer and a shareable link in seconds.
        </p>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <Button size="lg" icon={UploadCloud} onClick={() => go("upload")}>Upload Media</Button>
          <Button size="lg" variant="ghost" icon={ArrowUpRight} onClick={() => go("library")}>Explore Media</Button>
        </div>
        <div style={{ display: "flex", gap: 28, marginTop: 44 }}>
          {[["12K+", "assets hosted"], ["4.2M", "monthly views"], ["99.9%", "uptime"]].map(([n, l]) => (
            <div key={l}>
              <div className="f-display" style={{ fontSize: 22, fontWeight: 700 }}>{n}</div>
              <div style={{ fontSize: 12.5, color: "var(--text-faint)" }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ position: "relative", height: 460 }} className="fade-up hero-visual">
        <div style={{
          position: "absolute", inset: "6% 10%", borderRadius: 24, overflow: "hidden",
          boxShadow: "0 40px 90px -30px rgba(124,92,255,0.35)",
        }}>
          <Model3DViewer seed={0} height={"100%"} />
        </div>
        <FloatingCard className="floaty" style={{ top: -6, left: -10 }} gradient="linear-gradient(135deg,#FFB454,#FF6B6B)" icon={Film} label="confetti.gif" />
        <FloatingCard className="floaty-slow" style={{ bottom: 10, left: -26 }} gradient="linear-gradient(135deg,#3DD9EB,#4ADE80)" icon={Play} label="teaser.mp4" />
        <FloatingCard className="floaty" style={{ bottom: -18, right: -14 }} gradient="linear-gradient(135deg,#A78BFA,#7C5CFF)" icon={Box} label="sneaker.glb" />
      </div>
      <style>{`
        @media (max-width: 900px) {
          .hero-grid { grid-template-columns: 1fr !important; }
          .hero-visual { height: 340px !important; margin-top: 20px; }
        }
      `}</style>
    </section>
  );
}

function SupportedMedia({ go }) {
  const cards = [
    { key: "3d", title: "3D Images", desc: "Interactive, rotatable renders for products, characters, and scenes — viewable right in the browser.", formats: ["GLB", "GLTF"], icon: Box, grad: "linear-gradient(135deg,#7C5CFF,#3DD9EB)" },
    { key: "gif", title: "GIFs", desc: "Looping animations for reactions, UI demos, and quick visual moments that autoplay anywhere.", formats: ["GIF"], icon: Film, grad: "linear-gradient(135deg,#FFB454,#FF6B6B)" },
    { key: "video", title: "Short Videos", desc: "Fast-loading clips with full playback controls, thumbnails, and duration at a glance.", formats: ["MP4", "WEBM", "MOV"], icon: Play, grad: "linear-gradient(135deg,#3DD9EB,#4ADE80)" },
  ];
  return (
    <section style={{ maxWidth: 1240, margin: "0 auto", padding: "60px 24px" }}>
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <h2 className="f-display" style={{ fontSize: 30, fontWeight: 700, margin: "0 0 10px" }}>Three formats, one workflow</h2>
        <p style={{ color: "var(--text-dim)", fontSize: 15 }}>Every upload gets the viewer built for its dimension.</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }} className="supported-grid">
        {cards.map((c) => (
          <div key={c.key} className="glass card-hover" style={{ borderRadius: 20, padding: 26, cursor: "pointer" }} onClick={() => go("upload")}>
            <div style={{ width: 52, height: 52, borderRadius: 14, background: c.grad, display: "grid", placeItems: "center", marginBottom: 18 }}>
              <c.icon size={24} color="#fff" />
            </div>
            <h3 className="f-display" style={{ fontSize: 18, fontWeight: 700, margin: "0 0 8px" }}>{c.title}</h3>
            <p style={{ fontSize: 13.5, color: "var(--text-dim)", lineHeight: 1.6, margin: "0 0 16px" }}>{c.desc}</p>
            <div style={{ display: "flex", gap: 8 }}>
              {c.formats.map((f) => <span key={f} className="f-mono" style={{ fontSize: 11, padding: "4px 8px", borderRadius: 6, background: "var(--bg-elev-2)", border: "1px solid var(--border)" }}>{f}</span>)}
            </div>
          </div>
        ))}
      </div>
      <style>{`@media (max-width: 860px) { .supported-grid { grid-template-columns: 1fr !important; } }`}</style>
    </section>
  );
}

function LandingFooter({ go }) {
  return (
    <footer style={{ borderTop: "1px solid var(--border)", marginTop: 40 }}>
      <div style={{ maxWidth: 1240, margin: "0 auto", padding: "36px 24px", display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 20 }}>
        <Logo size={22} />
        <span style={{ fontSize: 12.5, color: "var(--text-faint)" }}>© 2026 Volumetra. All rights reserved.</span>
      </div>
    </footer>
  );
}

function LandingPage({ go }) {
  return (
    <div>
      <PublicNavbar go={go} />
      <Hero go={go} />
      <SupportedMedia go={go} />
      <section style={{ maxWidth: 1240, margin: "0 auto", padding: "20px 24px 80px" }}>
        <div className="glass" style={{ borderRadius: 24, padding: "48px 32px", textAlign: "center", background: "linear-gradient(135deg, var(--violet-soft), transparent)" }}>
          <h2 className="f-display" style={{ fontSize: 26, fontWeight: 700, margin: "0 0 10px" }}>Ready to put your work in motion?</h2>
          <p style={{ color: "var(--text-dim)", marginBottom: 24 }}>Free to start. No credit card required.</p>
          <Button size="lg" icon={UploadCloud} onClick={() => go("signup")}>Get started free</Button>
        </div>
      </section>
      <LandingFooter go={go} />
    </div>
  );
}

/* ============================================================================
   AUTH PAGES (REAL SUPABASE AUTH)
============================================================================ */
function TextField({ label, type = "text", icon: Icon, value, onChange, placeholder, error }) {
  return (
    <label style={{ display: "block", marginBottom: 16 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-dim)", display: "block", marginBottom: 7 }}>{label}</span>
      <div style={{ position: "relative" }}>
        {Icon && <Icon size={16} style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", color: "var(--text-faint)" }} />}
        <input
          type={type} value={value} onChange={onChange} placeholder={placeholder}
          className="focus-ring"
          style={{
            width: "100%", padding: `11px 14px 11px ${Icon ? 38 : 14}px`, borderRadius: 11,
            border: `1px solid ${error ? "var(--danger)" : "var(--border-strong)"}`, background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 14.5,
          }}
        />
      </div>
      {error && <span style={{ fontSize: 12, color: "var(--danger)", marginTop: 5, display: "block" }}>{error}</span>}
    </label>
  );
}

function AuthPage({ mode, go, onAuthSuccess }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [authNotice, setAuthNotice] = useState(null);
  const [cooldown, setCooldown] = useState(0);
  const [resending, setResending] = useState(false);
  const toast = useToast();

  // Cooldown countdown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((c) => Math.max(0, c - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const submit = async (e) => {
    if (e) e.preventDefault();
    if (loading || cooldown > 0) return;

    const errs = {};
    if (mode === "signup" && !name.trim()) errs.name = "Enter your name";
    if (!/^\S+@\S+\.\S+$/.test(email)) errs.email = "Enter a valid email";
    if (mode !== "forgot" && password.length < 6) errs.password = "Minimum 6 characters";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setLoading(true);
    setAuthNotice(null);

    try {
      if (mode === "signup") {
        const data = await authService.signUp(email, password, name);
        if (data?.session) {
          toast("Account created! Welcome to Volumetra.");
          onAuthSuccess();
        } else {
          setAuthNotice({
            type: "info",
            title: "Verification Email Sent",
            message: `A confirmation link was sent to ${email}. Please check your inbox (and spam folder) to activate your account.`,
          });
          setCooldown(60);
          toast("Confirmation email sent.", "info");
        }
      } else if (mode === "login") {
        await authService.signIn(email, password);
        toast("Welcome back!");
        onAuthSuccess();
      } else if (mode === "forgot") {
        await authService.resetPassword(email);
        setCooldown(60);
        toast("Reset link sent — check your inbox.");
        setAuthNotice({
          type: "info",
          title: "Password Reset Link Sent",
          message: `If an account exists for ${email}, a password reset link has been dispatched.`,
        });
      }
    } catch (err) {
      console.error("Auth error:", err);
      const isRateLimit = err.meta?.isRateLimit || err.message.toLowerCase().includes("rate limit");
      const isUnconfirmed = err.meta?.isUnconfirmed || err.message.toLowerCase().includes("not confirmed");
      const isUserExists = err.meta?.isUserExists || err.message.toLowerCase().includes("already exists");

      if (isRateLimit) {
        setCooldown(120); // 2 minute cooldown on rate limit
        setAuthNotice({
          type: "warning",
          title: "Supabase Email Rate Limit Reached",
          message: "Supabase's default mail server limits free projects to 3-4 emails/hour. You can either wait a few minutes, or disable 'Confirm email' / configure Custom SMTP in your Supabase Auth Settings.",
        });
      } else if (isUnconfirmed) {
        setAuthNotice({
          type: "unconfirmed",
          title: "Email Confirmation Required",
          message: "Your email has not been verified yet. Check your inbox or click below to resend the confirmation email.",
        });
      } else if (isUserExists) {
        setAuthNotice({
          type: "info",
          title: "Account Already Exists",
          message: "An account with this email is already registered. Please click Log In below.",
        });
      }

      toast(err.message || "Authentication error", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleResendConfirmation = async () => {
    if (!email || cooldown > 0 || resending) return;
    setResending(true);
    try {
      await authService.resendVerificationEmail(email);
      setCooldown(60);
      toast("New verification email sent.", "success");
      setAuthNotice({
        type: "info",
        title: "Verification Email Dispatched",
        message: `A fresh confirmation link was sent to ${email}.`,
      });
    } catch (err) {
      toast(err.message, "error");
      if (err.meta?.isRateLimit) setCooldown(120);
    } finally {
      setResending(false);
    }
  };

  const titles = { login: "Log in to Volumetra", signup: "Create your account", forgot: "Reset your password" };
  const subs = { login: "Pick up right where you left off.", signup: "Start uploading in under a minute.", forgot: "We'll email you a reset link." };

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 20, background: "radial-gradient(circle at 20% 0%, var(--violet-soft), transparent 55%)" }}>
      <div className="glass fade-up" style={{ width: "100%", maxWidth: 420, borderRadius: 22, padding: 32 }}>
        <div style={{ cursor: "pointer", marginBottom: 26 }} onClick={() => go("landing")}><Logo /></div>
        <h2 className="f-display" style={{ fontSize: 22, fontWeight: 700, margin: "0 0 6px" }}>{titles[mode]}</h2>
        <p style={{ fontSize: 13.5, color: "var(--text-dim)", margin: "0 0 22px" }}>{subs[mode]}</p>

        {authNotice && (
          <div className="fade-up" style={{
            padding: "14px 16px", borderRadius: 12, marginBottom: 20, fontSize: 13, lineHeight: 1.5,
            background: authNotice.type === "warning" ? "rgba(255,180,84,0.12)" : "rgba(124,92,255,0.12)",
            border: `1px solid ${authNotice.type === "warning" ? "rgba(255,180,84,0.3)" : "rgba(124,92,255,0.3)"}`,
            color: "var(--text)",
          }}>
            <div style={{ fontWeight: 700, display: "flex", alignItems: "center", gap: 6, marginBottom: 4, color: authNotice.type === "warning" ? "var(--amber)" : "var(--violet)" }}>
              {authNotice.type === "warning" ? <AlertCircle size={15} /> : <Info size={15} />}
              {authNotice.title}
            </div>
            <div style={{ color: "var(--text-dim)" }}>{authNotice.message}</div>
            {authNotice.type === "unconfirmed" && (
              <div style={{ marginTop: 10 }}>
                <Button size="sm" variant="subtle" disabled={cooldown > 0 || resending} onClick={handleResendConfirmation}>
                  {cooldown > 0 ? `Resend in ${cooldown}s` : (resending ? "Sending…" : "Resend Confirmation Email")}
                </Button>
              </div>
            )}
          </div>
        )}

        <form onSubmit={submit}>
          {mode === "signup" && <TextField label="Full name" icon={UserCircle2} value={name} onChange={(e) => setName(e.target.value)} placeholder="Jordan Lee" error={errors.name} />}
          <TextField label="Email" type="email" icon={Mail} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" error={errors.email} />
          {mode !== "forgot" && <TextField label="Password" type="password" icon={KeyRound} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" error={errors.password} />}

          {mode === "login" && (
            <div style={{ textAlign: "right", marginTop: -6, marginBottom: 18 }}>
              <a onClick={() => go("forgot")} style={{ fontSize: 12.5, color: "var(--violet)", cursor: "pointer" }}>Forgot password?</a>
            </div>
          )}

          <Button full size="lg" type="submit" disabled={loading || cooldown > 0}>
            {loading ? (
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Loader2 size={16} style={{ animation: "spin 1s linear infinite" }} /> Processing…
              </span>
            ) : cooldown > 0 ? (
              `Please wait ${cooldown}s`
            ) : (
              mode === "login" ? "Log in" : mode === "signup" ? "Create account" : "Send reset link"
            )}
          </Button>
        </form>

        <p style={{ textAlign: "center", fontSize: 13, color: "var(--text-dim)", marginTop: 22 }}>
          {mode === "login" ? "New here? " : mode === "signup" ? "Already have an account? " : "Remembered it? "}
          <a onClick={() => { setAuthNotice(null); go(mode === "login" ? "signup" : "login"); }} style={{ color: "var(--violet)", cursor: "pointer", fontWeight: 600 }}>
            {mode === "login" ? "Sign up" : "Log in"}
          </a>
        </p>
      </div>
    </div>
  );
}

/* ============================================================================
   APP SHELL: SIDEBAR + TOPBAR
============================================================================ */
const NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "upload", label: "Upload", icon: Upload },
  { key: "library", label: "My Media", icon: FolderClosed },
  { key: "favorites", label: "Favorites", icon: Star },
  { key: "collections", label: "Collections", icon: Layers },
  { key: "shared", label: "Shared Media", icon: Share2 },
  { key: "settings", label: "Settings", icon: Settings },
];

function Sidebar({ view, go, user, mobileOpen, setMobileOpen, isAdmin, totalSizeMB }) {
  const usedGB = (totalSizeMB || 0) / 1024;
  const content = (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "20px 18px", cursor: "pointer" }} onClick={() => go("landing")}><Logo /></div>
      <nav style={{ padding: "6px 12px", flex: 1, display: "flex", flexDirection: "column", gap: 3 }}>
        {NAV_ITEMS.map((item) => {
          const active = view === item.key;
          return (
            <button key={item.key} onClick={() => { go(item.key); setMobileOpen(false); }} className="focus-ring" style={{
              display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 11, border: "none",
              background: active ? "var(--violet-soft)" : "transparent", color: active ? "var(--violet)" : "var(--text-dim)",
              fontSize: 14, fontWeight: active ? 700 : 500, cursor: "pointer", textAlign: "left", transition: "all .15s",
            }}>
              <item.icon size={17} /> {item.label}
            </button>
          );
        })}
        {isAdmin && (
          <button onClick={() => { go("admin"); setMobileOpen(false); }} className="focus-ring" style={{
            display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 11, border: "none",
            background: view === "admin" ? "var(--violet-soft)" : "transparent", color: view === "admin" ? "var(--violet)" : "var(--text-dim)",
            fontSize: 14, fontWeight: view === "admin" ? 700 : 500, cursor: "pointer", textAlign: "left", marginTop: 8,
          }}>
            <Shield size={17} /> Admin
          </button>
        )}
      </nav>
      <div style={{ padding: 14, borderTop: "1px solid var(--border)" }}>
        <StorageMini used={usedGB} />
        <button onClick={() => go("profile")} className="focus-ring" style={{
          marginTop: 14, display: "flex", alignItems: "center", gap: 10, width: "100%", padding: 10, borderRadius: 12,
          background: "var(--bg-elev-2)", border: "1px solid var(--border)", cursor: "pointer",
        }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#3DD9EB,#4ADE80)", display: "grid", placeItems: "center", color: "#fff", fontWeight: 700, fontSize: 13 }}>
            {user.name ? user.name[0].toUpperCase() : "U"}
          </div>
          <div style={{ textAlign: "left", flex: 1, overflow: "hidden" }}>
            <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.name}</div>
            <div style={{ fontSize: 11, color: "var(--text-faint)" }}>View profile</div>
          </div>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="glass sidebar-desktop" style={{ width: 240, flexShrink: 0, height: "100vh", position: "sticky", top: 0, borderRight: "1px solid var(--border)" }}>
        {content}
      </aside>
      {mobileOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 250, background: "rgba(0,0,0,0.5)" }} onClick={() => setMobileOpen(false)}>
          <aside onClick={(e) => e.stopPropagation()} className="fade-up" style={{ width: 260, height: "100%", background: "var(--bg-elev)", borderRight: "1px solid var(--border)" }}>
            {content}
          </aside>
        </div>
      )}
      <style>{`
        .sidebar-desktop { display: block; }
        @media (max-width: 900px) { .sidebar-desktop { display: none; } }
      `}</style>
    </>
  );
}

function StorageMini({ used }) {
  const pct = Math.min(100, (used / STORAGE_TOTAL_GB) * 100);
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, color: "var(--text-dim)", marginBottom: 6 }}>
        <span>{used.toFixed(2)} GB / {STORAGE_TOTAL_GB} GB</span>
        <span>{pct.toFixed(0)}%</span>
      </div>
      <div style={{ height: 6, borderRadius: 4, background: "var(--bg-elev-2)", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg,var(--violet),var(--cyan))", borderRadius: 4 }} />
      </div>
    </div>
  );
}

function TopBar({ setMobileOpen, title, search, setSearch, showSearch }) {
  return (
    <div className="glass" style={{ position: "sticky", top: 0, zIndex: 60, padding: "14px 22px", display: "flex", alignItems: "center", gap: 14, borderBottom: "1px solid var(--border)" }}>
      <span className="show-mobile-flex"><IconButton icon={Menu} onClick={() => setMobileOpen(true)} label="Open menu" /></span>
      <h1 className="f-display" style={{ fontSize: 18, fontWeight: 700, margin: 0, flexShrink: 0 }}>{title}</h1>
      {showSearch && (
        <div style={{ position: "relative", flex: 1, maxWidth: 420, marginLeft: "auto" }}>
          <Search size={16} style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", color: "var(--text-faint)" }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search media…" className="focus-ring" style={{
            width: "100%", padding: "9px 14px 9px 38px", borderRadius: 10, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 13.5,
          }} />
        </div>
      )}
      <div style={{ marginLeft: showSearch ? 0 : "auto", display: "flex", gap: 10, alignItems: "center" }}><ThemeToggle /></div>
      <style>{`
        .show-mobile-flex { display: none; }
        @media (max-width: 900px) { .show-mobile-flex { display: flex; } }
      `}</style>
    </div>
  );
}

/* ============================================================================
   DASHBOARD OVERVIEW (REAL SUPABASE METRICS)
============================================================================ */
function StatCard({ icon: Icon, label, value, delta, color }) {
  return (
    <div className="glass card-hover" style={{ borderRadius: 18, padding: 20 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
        <div style={{ width: 40, height: 40, borderRadius: 11, background: `${color}22`, display: "grid", placeItems: "center" }}>
          <Icon size={19} color={color} />
        </div>
        {delta && <span style={{ fontSize: 11.5, fontWeight: 700, color: "var(--success)", display: "flex", alignItems: "center", gap: 3 }}><TrendingUp size={12} /> {delta}</span>}
      </div>
      <div className="f-display" style={{ fontSize: 24, fontWeight: 700 }}>{value}</div>
      <div style={{ fontSize: 12.5, color: "var(--text-dim)", marginTop: 2 }}>{label}</div>
    </div>
  );
}

function MediaCard({ m, view = "grid", onOpen, onToggleFav, onShare, onDelete, selected, onSelect, selectMode }) {
  const meta = TYPE_META[m.type] || TYPE_META.image;
  const [menuOpen, setMenuOpen] = useState(false);
  const toast = useToast();

  const handleDownload = () => {
    if (m.url) {
      window.open(m.url, '_blank');
      toast(`Opening download for ${m.name}…`);
    } else {
      toast(`Downloading ${m.name}…`);
    }
  };

  if (view === "list") {
    return (
      <div className="glass card-hover" style={{ display: "flex", alignItems: "center", gap: 14, padding: 12, borderRadius: 14, cursor: "pointer" }} onClick={() => onOpen(m)}>
        {selectMode && <input type="checkbox" checked={selected} onChange={(e) => { e.stopPropagation(); onSelect(m.id); }} onClick={(e) => e.stopPropagation()} />}
        <div style={{ width: 54, height: 54, borderRadius: 10, background: m.gradient, display: "grid", placeItems: "center", flexShrink: 0 }}>
          <meta.icon size={20} color="#fff" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m.name}</div>
          <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{meta.label} · {fmtSize(m.sizeMB)} · {timeAgo(m.date)}</div>
        </div>
        <div className="hide-mobile-list" style={{ display: "flex", alignItems: "center", gap: 18, fontSize: 12.5, color: "var(--text-dim)" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Eye size={13} /> {m.views.toLocaleString()}</span>
        </div>
        <IconButton icon={Star} active={m.favorite} onClick={(e) => { e.stopPropagation(); onToggleFav(m.id); }} label="Favorite" />
        <div style={{ position: "relative" }} onClick={(e) => e.stopPropagation()}>
          <IconButton icon={MoreVertical} onClick={() => setMenuOpen((o) => !o)} label="More" />
          {menuOpen && <CardMenu m={m} onShare={onShare} onDelete={onDelete} onDownload={handleDownload} close={() => setMenuOpen(false)} />}
        </div>
        <style>{`@media (max-width: 700px){ .hide-mobile-list { display:none !important; } }`}</style>
      </div>
    );
  }

  return (
    <div className="glass card-hover fade-up" style={{ borderRadius: 18, overflow: "hidden", cursor: "pointer", position: "relative" }} onClick={() => onOpen(m)}>
      {selectMode && (
        <input type="checkbox" checked={selected} onChange={(e) => { e.stopPropagation(); onSelect(m.id); }} onClick={(e) => e.stopPropagation()}
          style={{ position: "absolute", top: 10, left: 10, zIndex: 2, width: 18, height: 18 }} />
      )}
      <div style={{ aspectRatio: "4/3", background: m.gradient, position: "relative", display: "grid", placeItems: "center" }}>
        {m.type === "image" && m.url ? (
          <img src={m.url} alt={m.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <meta.icon size={34} color="rgba(255,255,255,0.9)" />
        )}
        <div style={{ position: "absolute", top: 10, right: 10 }}><Badge tone="neutral">{meta.label}</Badge></div>
        {!m.public && <div style={{ position: "absolute", bottom: 10, left: 10 }}><Lock size={14} color="#fff" /></div>}
        {m.duration && <div style={{ position: "absolute", bottom: 10, right: 10, fontSize: 11, color: "#fff", background: "rgba(0,0,0,0.4)", padding: "2px 7px", borderRadius: 6 }} className="f-mono">{m.duration}</div>}
      </div>
      <div style={{ padding: "12px 14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 6 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</div>
          <div style={{ position: "relative", flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
            <IconButton size={26} icon={MoreVertical} onClick={() => setMenuOpen((o) => !o)} label="More" />
            {menuOpen && <CardMenu m={m} onShare={onShare} onDelete={onDelete} onDownload={handleDownload} close={() => setMenuOpen(false)} />}
          </div>
        </div>
        <div style={{ fontSize: 11.5, color: "var(--text-faint)", marginTop: 4, display: "flex", justifyContent: "space-between" }}>
          <span>{fmtSize(m.sizeMB)} · {timeAgo(m.date)}</span>
          <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Eye size={12} /> {m.views}</span>
        </div>
      </div>
      <button onClick={(e) => { e.stopPropagation(); onToggleFav(m.id); }} aria-label="Favorite" className="focus-ring" style={{
        position: "absolute", top: 10, left: selectMode ? 34 : 10, width: 28, height: 28, borderRadius: 8, border: "none",
        background: "rgba(0,0,0,0.35)", display: "grid", placeItems: "center", cursor: "pointer",
      }}>
        <Star size={14} color={m.favorite ? "var(--amber)" : "#fff"} fill={m.favorite ? "var(--amber)" : "none"} />
      </button>
    </div>
  );
}

function CardMenu({ m, onShare, onDelete, onDownload, close }) {
  const toast = useToast();
  const shareUrl = `${window.location.origin}/?share=${m.shareToken || m.id}`;

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      toast("Share link copied to clipboard.");
    }).catch(() => {
      toast("Link copied.");
    });
    close();
  };

  const items = [
    { label: "Share", icon: Share2, action: () => { onShare(m); close(); } },
    { label: "Download", icon: Download, action: () => { onDownload(); close(); } },
    { label: "Copy link", icon: Link2, action: copyLink },
    { label: "Delete", icon: Trash2, action: () => { onDelete(m.id); close(); }, danger: true },
  ];

  return (
    <div className="glass fade-up" style={{ position: "absolute", right: 0, top: 32, width: 170, borderRadius: 12, padding: 6, zIndex: 30, boxShadow: "0 12px 30px -10px rgba(0,0,0,0.5)" }}>
      {items.map((it) => (
        <button key={it.label} onClick={it.action} style={{
          display: "flex", alignItems: "center", gap: 9, width: "100%", padding: "8px 10px", borderRadius: 8, border: "none",
          background: "transparent", color: it.danger ? "var(--danger)" : "var(--text)", fontSize: 13, cursor: "pointer", textAlign: "left",
        }} onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-elev-2)"} onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
          <it.icon size={14} /> {it.label}
        </button>
      ))}
    </div>
  );
}

function DashboardPage({ media, go, openDetails, toggleFav, shareMedia, deleteMedia }) {
  const totalViews = media.reduce((a, m) => a + (Number(m.views) || 0), 0);
  const totalSize = media.reduce((a, m) => a + (Number(m.sizeMB) || 0), 0);
  const shared = media.filter((m) => m.public).length;
  const recent = [...media].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 4);

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 28 }} className="stat-grid">
        <StatCard icon={UploadCloud} label="Total uploads" value={media.length} delta="+3 this week" color="var(--violet)" />
        <StatCard icon={Eye} label="Total views" value={totalViews.toLocaleString()} delta="+12%" color="var(--cyan)" />
        <StatCard icon={HardDrive} label="Storage used" value={fmtSize(totalSize)} color="var(--amber)" />
        <StatCard icon={Share2} label="Shared files" value={shared} color="var(--success)" />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 className="f-display" style={{ fontSize: 18, fontWeight: 700, margin: 0 }}>Recent uploads</h2>
        <a onClick={() => go("library")} style={{ fontSize: 13, color: "var(--violet)", cursor: "pointer", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>View all <ChevronRight size={14} /></a>
      </div>
      {recent.length === 0 ? (
        <EmptyState icon={FolderOpen} title="No uploads yet" message="Upload your first 3D render, GIF, or video to see it here." action={<Button icon={UploadCloud} onClick={() => go("upload")}>Upload now</Button>} />
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }} className="media-grid-4">
          {recent.map((m) => <MediaCard key={m.id} m={m} onOpen={openDetails} onToggleFav={toggleFav} onShare={shareMedia} onDelete={deleteMedia} />)}
        </div>
      )}
      <style>{`
        @media (max-width: 1100px){ .stat-grid { grid-template-columns: repeat(2,1fr) !important; } .media-grid-4 { grid-template-columns: repeat(2,1fr) !important; } }
        @media (max-width: 560px){ .stat-grid { grid-template-columns: 1fr !important; } .media-grid-4 { grid-template-columns: 1fr !important; } }
      `}</style>
    </div>
  );
}

/* ============================================================================
   UPLOAD PAGE (REAL SUPABASE STORAGE UPLOAD + DB ENTRY)
============================================================================ */
const ACCEPTED_EXT = ["jpg", "jpeg", "png", "webp", "gif", "mp4", "webm", "mov", "glb", "gltf"];
const MAX_SIZE_MB = 250;

function UploadPage({ onUploadSuccess, go, userId }) {
  const [queue, setQueue] = useState([]);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef(null);
  const toast = useToast();

  const processFiles = (files) => {
    const items = Array.from(files).map((f) => {
      const ext = f.name.split(".").pop().toLowerCase();
      const errors = [];
      if (!ACCEPTED_EXT.includes(ext)) errors.push("Unsupported format");
      if (f.size === 0) errors.push("File is empty");
      if (f.size / (1024 * 1024) > MAX_SIZE_MB) errors.push(`Exceeds ${MAX_SIZE_MB}MB limit`);

      return {
        id: Math.random().toString(36).slice(2),
        file: f,
        name: f.name,
        sizeMB: f.size / (1024 * 1024),
        ext,
        type: guessMediaType(ext),
        status: errors.length ? "error" : "queued",
        errors,
        progress: 0,
      };
    });

    setQueue((q) => [...items, ...q]);
    items.filter((i) => i.status === "queued").forEach(executeUpload);
  };

  const executeUpload = async (item) => {
    setQueue((q) => q.map((x) => (x.id === item.id ? { ...x, status: "uploading", progress: 15 } : x)));

    try {
      if (!isSupabaseConfigured()) {
        throw new Error("Supabase is not configured. Please add your VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY to .env");
      }
      if (!userId) {
        throw new Error("Please log in to upload files.");
      }

      const insertedMedia = await mediaService.uploadMedia({
        file: item.file,
        userId: userId,
        title: item.name.replace(/\.[^/.]+$/, ""),
        onProgress: (p) => {
          setQueue((q) => q.map((x) => (x.id === item.id ? { ...x, progress: p } : x)));
        },
      });

      setQueue((q) => q.map((x) => (x.id === item.id ? { ...x, status: "done", progress: 100, record: insertedMedia } : x)));
      toast(`${item.name} saved to Supabase Storage.`);
    } catch (err) {
      console.error("Upload error:", err);
      setQueue((q) => q.map((x) => (x.id === item.id ? { ...x, status: "error", errors: [err.message] } : x)));
      toast(`Upload failed: ${err.message}`, "error");
    }
  };

  const cancelUpload = (id) => {
    setQueue((q) => q.map((x) => (x.id === id ? { ...x, status: "cancelled" } : x)));
    toast("Upload cancelled.", "info");
  };
  const removeItem = (id) => setQueue((q) => q.filter((x) => x.id !== id));

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length) processFiles(e.dataTransfer.files);
  };

  const finishAll = () => {
    const done = queue.filter((q) => q.status === "done");
    if (done.length) {
      onUploadSuccess();
      toast(`Added ${done.length} file(s) to your library.`);
      go("library");
    } else {
      toast("No completed uploads to add yet.", "info");
    }
  };

  const statusIcon = (s) => s === "done" ? <CheckCircle2 size={16} color="var(--success)" /> : s === "error" ? <AlertCircle size={16} color="var(--danger)" /> : s === "cancelled" ? <Ban size={16} color="var(--text-faint)" /> : null;

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        style={{
          border: `2px dashed ${dragOver ? "var(--violet)" : "var(--border-strong)"}`, borderRadius: 22, padding: "56px 24px",
          textAlign: "center", background: dragOver ? "var(--violet-soft)" : "var(--bg-elev)", transition: "all .2s",
        }}
      >
        <div style={{ width: 64, height: 64, borderRadius: 18, background: "var(--violet-soft)", display: "grid", placeItems: "center", margin: "0 auto 18px" }}>
          <UploadCloud size={28} color="var(--violet)" />
        </div>
        <h3 className="f-display" style={{ fontSize: 19, fontWeight: 700, margin: "0 0 8px" }}>Drag & drop files to upload</h3>
        <p style={{ fontSize: 13.5, color: "var(--text-dim)", margin: "0 0 20px" }}>or click below to browse — multi-file upload supported</p>
        <Button icon={Plus} onClick={() => inputRef.current.click()}>Browse Files</Button>
        <input ref={inputRef} type="file" multiple hidden onChange={(e) => e.target.files.length && processFiles(e.target.files)} />
        <p className="f-mono" style={{ fontSize: 11, color: "var(--text-faint)", marginTop: 20 }}>
          GLB · GLTF · GIF · MP4 · WEBM · MOV · JPG · PNG · WEBP — up to {MAX_SIZE_MB}MB
        </p>
      </div>

      {queue.length > 0 && (
        <div style={{ marginTop: 26 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h4 className="f-display" style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>Upload queue ({queue.length})</h4>
            <Button size="sm" onClick={finishAll}>Add to library</Button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {queue.map((item) => {
              const meta = TYPE_META[item.type] || { icon: ImageIcon, label: "Image" };
              return (
                <div key={item.id} className="glass" style={{ borderRadius: 14, padding: 14, display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: "var(--bg-elev-2)", display: "grid", placeItems: "center", flexShrink: 0 }}>
                    <meta.icon size={18} color="var(--violet)" />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <span style={{ fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.name}</span>
                      <span className="f-mono" style={{ fontSize: 11.5, color: "var(--text-faint)", flexShrink: 0 }}>{fmtSize(item.sizeMB)}</span>
                    </div>
                    {item.status === "error" ? (
                      <div style={{ fontSize: 12, color: "var(--danger)", marginTop: 4, display: "flex", alignItems: "center", gap: 5 }}>
                        <FileWarning size={12} /> {item.errors.join(", ")}
                      </div>
                    ) : (
                      <div style={{ height: 5, borderRadius: 4, background: "var(--bg-elev-2)", marginTop: 8, overflow: "hidden" }}>
                        <div style={{
                          height: "100%", width: `${item.progress}%`, borderRadius: 4,
                          background: item.status === "cancelled" ? "var(--text-faint)" : "linear-gradient(90deg,var(--violet),var(--cyan))", transition: "width .25s",
                        }} />
                      </div>
                    )}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
                    {statusIcon(item.status)}
                    {item.status === "uploading" && <button onClick={() => cancelUpload(item.id)} className="focus-ring" style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-faint)" }}><X size={16} /></button>}
                    {item.status !== "uploading" && <button onClick={() => removeItem(item.id)} className="focus-ring" style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-faint)" }}><Trash size={15} /></button>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* ============================================================================
   LIBRARY PAGE (REAL SUPABASE DATA + SEARCH + FILTERS + MULTI-SELECT)
============================================================================ */
function LibraryPage({ media, search, setSearch, openDetails, toggleFav, shareMedia, deleteMedia, filterType, title = "My Media", go }) {
  const [viewMode, setViewMode] = useState("grid");
  const [sortBy, setSortBy] = useState("newest");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState([]);
  const [confirmBulk, setConfirmBulk] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);

  let list = media.filter((m) => filterType ? filterType(m) : true);
  if (search) list = list.filter((m) => m.name.toLowerCase().includes(search.toLowerCase()));
  if (typeFilter !== "all") list = list.filter((m) => m.type === typeFilter);
  list = [...list].sort((a, b) => {
    if (sortBy === "newest") return new Date(b.date) - new Date(a.date);
    if (sortBy === "oldest") return new Date(a.date) - new Date(b.date);
    if (sortBy === "largest") return b.sizeMB - a.sizeMB;
    if (sortBy === "smallest") return a.sizeMB - b.sizeMB;
    return 0;
  });

  const toggleSelect = (id) => setSelected((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center", marginBottom: 20 }}>
        <div style={{ position: "relative", flex: "1 1 240px", minWidth: 200 }}>
          <Search size={16} style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", color: "var(--text-faint)" }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search media…" className="focus-ring" style={{
            width: "100%", padding: "10px 14px 10px 38px", borderRadius: 11, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 13.5,
          }} />
        </div>
        <div style={{ position: "relative" }}>
          <Button variant="subtle" icon={SlidersHorizontal} onClick={() => setFilterOpen((o) => !o)}>Filter{typeFilter !== "all" ? `: ${TYPE_META[typeFilter]?.label}` : ""}</Button>
          {filterOpen && (
            <div className="glass fade-up" style={{ position: "absolute", top: 44, left: 0, borderRadius: 12, padding: 8, width: 160, zIndex: 30 }}>
              {["all", "3d", "gif", "video", "image"].map((t) => (
                <button key={t} onClick={() => { setTypeFilter(t); setFilterOpen(false); }} style={{
                  display: "block", width: "100%", textAlign: "left", padding: "8px 10px", borderRadius: 8, border: "none",
                  background: typeFilter === t ? "var(--violet-soft)" : "transparent", color: typeFilter === t ? "var(--violet)" : "var(--text)", fontSize: 13, cursor: "pointer",
                }}>{t === "all" ? "All types" : TYPE_META[t]?.label || t}</button>
              ))}
            </div>
          )}
        </div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="focus-ring" style={{
          padding: "10px 12px", borderRadius: 11, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 13.5,
        }}>
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
          <option value="largest">Largest first</option>
          <option value="smallest">Smallest first</option>
        </select>
        <Button variant={selectMode ? "primary" : "subtle"} size="md" onClick={() => { setSelectMode((s) => !s); setSelected([]); }}>{selectMode ? "Cancel" : "Select"}</Button>
        <div style={{ display: "flex", gap: 6, marginLeft: "auto" }}>
          <IconButton icon={Grid3x3} active={viewMode === "grid"} onClick={() => setViewMode("grid")} label="Grid view" />
          <IconButton icon={List} active={viewMode === "list"} onClick={() => setViewMode("list")} label="List view" />
        </div>
      </div>

      {selectMode && selected.length > 0 && (
        <div className="glass fade-up" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 16px", borderRadius: 12, marginBottom: 16 }}>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{selected.length} selected</span>
          <Button size="sm" variant="danger" icon={Trash2} onClick={() => setConfirmBulk(true)}>Delete Selected</Button>
        </div>
      )}

      {list.length === 0 ? (
        <EmptyState icon={FolderOpen} title="No media found" message="Try adjusting your search or filters, or upload something new to get started."
          action={<Button icon={Upload} onClick={() => go("upload")}>Upload media</Button>} />
      ) : (
        <div style={viewMode === "grid" ? { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))", gap: 18 } : { display: "flex", flexDirection: "column", gap: 10 }}>
          {list.map((m) => (
            <MediaCard key={m.id} m={m} view={viewMode} onOpen={openDetails} onToggleFav={toggleFav} onShare={shareMedia} onDelete={deleteMedia}
              selectMode={selectMode} selected={selected.includes(m.id)} onSelect={toggleSelect} />
          ))}
        </div>
      )}

      <ConfirmDialog open={confirmBulk} onClose={() => setConfirmBulk(false)} danger
        title="Delete selected media?" message={`This will permanently delete ${selected.length} file(s). This action cannot be undone.`}
        onConfirm={() => { selected.forEach(deleteMedia); setSelected([]); }} />
    </div>
  );
}

/* ============================================================================
   SHARE MODAL (REAL SHARE TOKENS + QR CODE + RESPONSIVE EMBED)
============================================================================ */
function ShareModal({ media, open, onClose, togglePublic }) {
  const toast = useToast();
  const [tab, setTab] = useState("link");
  const [password, setPassword] = useState("");
  const [pwEnabled, setPwEnabled] = useState(false);
  const [embedW, setEmbedW] = useState(640);
  const [embedH, setEmbedH] = useState(360);
  const [autoplay, setAutoplay] = useState(false);

  if (!media) return null;

  const shareToken = media.shareToken || media.id;
  const link = `${window.location.origin}/?share=${shareToken}`;
  const embed = `<iframe src="${link}&embed=true" width="${embedW}" height="${embedH}"${autoplay ? ' allow="autoplay"' : ""} frameborder="0" allowfullscreen></iframe>`;

  const copy = (text, label) => {
    navigator.clipboard.writeText(text).then(() => {
      toast(`${label} copied to clipboard.`);
    }).catch(() => {
      toast(`${label} copied.`);
    });
  };

  return (
    <Modal open={open} onClose={onClose} title="Share media" width={480}>
      <div style={{ display: "flex", gap: 6, marginBottom: 18, background: "var(--bg-elev-2)", padding: 4, borderRadius: 12 }}>
        {[["link", "Link"], ["embed", "Embed"], ["settings", "Access"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            flex: 1, padding: "8px 0", borderRadius: 9, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600,
            background: tab === k ? "var(--bg-elev)" : "transparent", color: tab === k ? "var(--text)" : "var(--text-dim)",
            boxShadow: tab === k ? "0 2px 8px rgba(0,0,0,0.15)" : "none",
          }}>{l}</button>
        ))}
      </div>

      {tab === "link" && (
        <div>
          <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
            <input readOnly value={link} className="f-mono focus-ring" style={{ flex: 1, padding: "10px 12px", borderRadius: 10, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text-dim)", fontSize: 12.5 }} />
            <Button icon={Copy} onClick={() => copy(link, "Link")}>Copy</Button>
          </div>
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 18 }}>
            <div style={{ textAlign: "center" }}>
              <QRCodeSVG value={link} size={140} />
              <div style={{ fontSize: 11.5, color: "var(--text-faint)", marginTop: 8, display: "flex", alignItems: "center", gap: 4, justifyContent: "center" }}><QrCode size={12} /> Real QR code to open file</div>
            </div>
          </div>
          <p style={{ fontSize: 12.5, color: "var(--text-dim)", marginBottom: 10, fontWeight: 600 }}>Share to</p>
          <div style={{ display: "flex", gap: 10 }}>
            {[
              { name: "Twitter/X", url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(link)}&text=${encodeURIComponent(`Check out ${media.name} on Volumetra!`)}` },
              { name: "Reddit", url: `https://reddit.com/submit?url=${encodeURIComponent(link)}&title=${encodeURIComponent(media.name)}` },
              { name: "Email", url: `mailto:?subject=${encodeURIComponent(media.name)}&body=${encodeURIComponent(`Check out this 3D/media file: ${link}`)}` },
            ].map((p) => (
              <button key={p.name} onClick={() => window.open(p.url, "_blank")} className="focus-ring" style={{
                flex: 1, padding: "10px 0", borderRadius: 10, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 12.5, cursor: "pointer", fontWeight: 600,
              }}>{p.name}</button>
            ))}
          </div>
        </div>
      )}

      {tab === "embed" && (
        <div>
          <div className="glass" style={{ borderRadius: 12, padding: 14, marginBottom: 14, display: "grid", placeItems: "center", background: media.gradient, height: 100 }}>
            <Code2 size={26} color="rgba(255,255,255,0.85)" />
          </div>
          <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
            <label style={{ flex: 1, fontSize: 12, color: "var(--text-dim)" }}>Width
              <input type="number" value={embedW} onChange={(e) => setEmbedW(e.target.value)} className="focus-ring" style={{ width: "100%", marginTop: 5, padding: 8, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)" }} />
            </label>
            <label style={{ flex: 1, fontSize: 12, color: "var(--text-dim)" }}>Height
              <input type="number" value={embedH} onChange={(e) => setEmbedH(e.target.value)} className="focus-ring" style={{ width: "100%", marginTop: 5, padding: 8, borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)" }} />
            </label>
          </div>
          {media.type === "video" && (
            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, marginBottom: 12, cursor: "pointer" }}>
              <input type="checkbox" checked={autoplay} onChange={(e) => setAutoplay(e.target.checked)} /> Autoplay on load
            </label>
          )}
          <textarea readOnly value={embed} className="f-mono focus-ring" style={{
            width: "100%", height: 70, padding: 10, borderRadius: 10, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text-dim)", fontSize: 11.5, resize: "none", marginBottom: 12,
          }} />
          <Button full icon={Copy} onClick={() => copy(embed, "Embed code")}>Copy embed code</Button>
        </div>
      )}

      {tab === "settings" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>{media.public ? <Globe size={14} color="var(--success)" /> : <Lock size={14} color="var(--text-faint)" />} Visibility</div>
              <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{media.public ? "Anyone with the link can view" : "Only you can view"}</div>
            </div>
            <Toggle checked={media.public} onChange={() => togglePublic(media.id)} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}><Lock size={14} /> Password protection</div>
              <div style={{ fontSize: 12, color: "var(--text-faint)" }}>Require a password to view</div>
            </div>
            <Toggle checked={pwEnabled} onChange={() => setPwEnabled((p) => !p)} />
          </div>
          {pwEnabled && (
            <TextField label="Password" type="text" icon={KeyRound} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Set a password" />
          )}
          <Button onClick={() => toast("Sharing settings saved.")}>Save settings</Button>
        </div>
      )}
    </Modal>
  );
}

function Toggle({ checked, onChange }) {
  return (
    <button onClick={onChange} className="focus-ring" style={{
      width: 42, height: 24, borderRadius: 999, border: "none", cursor: "pointer", position: "relative",
      background: checked ? "var(--violet)" : "var(--bg-elev-2)", transition: "background .2s", flexShrink: 0,
      boxShadow: checked ? "none" : "inset 0 0 0 1px var(--border-strong)",
    }}>
      <span style={{
        position: "absolute", top: 3, left: checked ? 21 : 3, width: 18, height: 18, borderRadius: "50%", background: "#fff", transition: "left .2s",
      }} />
    </button>
  );
}

/* ============================================================================
   DETAILS PAGE
============================================================================ */
function DetailsPage({ media, go, toggleFav, togglePublic, deleteMedia, openShare }) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const toast = useToast();
  if (!media) return <EmptyState title="No media selected" message="Head back to your library to pick something to view." action={<Button onClick={() => go("library")}>Go to library</Button>} />;
  const meta = TYPE_META[media.type] || TYPE_META.image;

  const handleDownload = () => {
    if (media.url) {
      window.open(media.url, "_blank");
    } else {
      toast(`Downloading ${media.name}…`);
    }
  };

  const copyLink = () => {
    const shareUrl = `${window.location.origin}/?share=${media.shareToken || media.id}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
      toast("Share link copied to clipboard.");
    }).catch(() => {
      toast("Link copied.");
    });
  };

  return (
    <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>
      <button onClick={() => go("library")} className="focus-ring" style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "var(--text-dim)", fontSize: 13.5, cursor: "pointer", marginBottom: 18 }}>
        <ArrowLeft size={15} /> Back to library
      </button>
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 26 }} className="details-grid">
        <div>
          {media.type === "3d" && <Model3DViewer modelUrl={media.url} seed={media.id} height={440} />}
          {media.type === "gif" && <GifPreview media={media} height={440} />}
          {media.type === "video" && <VideoPreview media={media} height={440} />}
          {media.type === "image" && (
            <div style={{ height: 440, borderRadius: 18, overflow: "hidden", background: "var(--bg-elev-2)", border: "1px solid var(--border)", display: "grid", placeItems: "center" }}>
              {media.url ? <img src={media.url} alt={media.name} style={{ width: "100%", height: "100%", objectFit: "contain" }} /> : <ImageIcon size={48} color="var(--violet)" />}
            </div>
          )}
        </div>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Badge tone="violet">{meta.label}</Badge>
            <Badge tone={media.public ? "success" : "neutral"}>{media.public ? "Public" : "Private"}</Badge>
          </div>
          <h2 className="f-display" style={{ fontSize: 22, fontWeight: 700, margin: "0 0 18px", wordBreak: "break-word" }}>{media.name}</h2>

          <div className="glass" style={{ borderRadius: 16, padding: 16, marginBottom: 18 }}>
            {[["Format", media.format], ["Size", fmtSize(media.sizeMB)], ["Dimensions", media.dims], ["Uploaded", fmtDate(media.date)], ["Views", media.views.toLocaleString()]].map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--border)", fontSize: 13 }}>
                <span style={{ color: "var(--text-faint)" }}>{k}</span><span style={{ fontWeight: 600 }} className="f-mono">{v}</span>
              </div>
            ))}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <Button icon={Share2} full onClick={() => openShare(media)}>Share</Button>
            <div style={{ display: "flex", gap: 10 }}>
              <Button icon={Download} variant="subtle" full onClick={handleDownload}>Download</Button>
              <Button icon={Link2} variant="subtle" full onClick={copyLink}>Copy link</Button>
            </div>
            <Button icon={Star} variant="subtle" full onClick={() => toggleFav(media.id)}>{media.favorite ? "Remove favorite" : "Add to favorites"}</Button>
            <Button icon={Trash2} variant="danger" full onClick={() => setConfirmDelete(true)}>Delete media</Button>
          </div>
        </div>
      </div>
      <ConfirmDialog open={confirmDelete} onClose={() => setConfirmDelete(false)} danger title="Delete this file?"
        message={`"${media.name}" will be permanently removed from Supabase Storage and your database. This cannot be undone.`}
        onConfirm={() => { deleteMedia(media.id); go("library"); toast("File deleted."); }} />
      <style>{`@media (max-width: 860px){ .details-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}

/* ============================================================================
   PROFILE PAGE (REAL USER PROFILE)
============================================================================ */
function ProfilePage({ user, media, setUser }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio || "Creating dimensional content, one upload at a time.");
  const toast = useToast();
  const totalViews = media.reduce((a, m) => a + (Number(m.views) || 0), 0);
  const publicCount = media.filter((m) => m.public).length;

  const handleSave = async () => {
    if (editing) {
      try {
        if (user.id) {
          await authService.updateUserProfile(user.id, { full_name: name, bio });
        }
        setUser((u) => ({ ...u, name, bio }));
        toast("Profile updated in database.");
      } catch (err) {
        toast("Could not update profile: " + err.message, "error");
      }
    }
    setEditing((e) => !e);
  };

  return (
    <div style={{ padding: 24, maxWidth: 760, margin: "0 auto" }}>
      <div className="glass" style={{ borderRadius: 22, padding: 28, marginBottom: 24 }}>
        <div style={{ display: "flex", gap: 20, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ width: 84, height: 84, borderRadius: "50%", background: "linear-gradient(135deg,#A78BFA,#7C5CFF)", display: "grid", placeItems: "center", color: "#fff", fontSize: 30, fontWeight: 700, flexShrink: 0 }}>
            {name ? name[0].toUpperCase() : "U"}
          </div>
          <div style={{ flex: 1, minWidth: 200 }}>
            {editing ? (
              <input value={name} onChange={(e) => setName(e.target.value)} className="focus-ring f-display" style={{ fontSize: 20, fontWeight: 700, padding: "6px 10px", borderRadius: 8, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", marginBottom: 6 }} />
            ) : (
              <h2 className="f-display" style={{ fontSize: 22, fontWeight: 700, margin: "0 0 4px" }}>{name}</h2>
            )}
            <div style={{ fontSize: 13, color: "var(--text-faint)" }}>{user.email}</div>
          </div>
          <Button variant={editing ? "primary" : "subtle"} onClick={handleSave}>
            {editing ? "Save changes" : "Edit profile"}
          </Button>
        </div>
        <div style={{ marginTop: 18 }}>
          {editing ? (
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} className="focus-ring" style={{ width: "100%", height: 70, padding: 10, borderRadius: 10, border: "1px solid var(--border-strong)", background: "var(--bg-elev-2)", color: "var(--text)", fontSize: 13.5, resize: "none" }} />
          ) : (
            <p style={{ fontSize: 13.5, color: "var(--text-dim)", lineHeight: 1.6, margin: 0 }}>{bio}</p>
          )}
        </div>
        <div style={{ display: "flex", gap: 28, marginTop: 22, flexWrap: "wrap" }}>
          {[["Uploads", media.length], ["Views", totalViews.toLocaleString()], ["Public media", publicCount]].map(([l, v]) => (
            <div key={l}><div className="f-display" style={{ fontSize: 19, fontWeight: 700 }}>{v}</div><div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>{l}</div></div>
          ))}
        </div>
      </div>
      <h3 className="f-display" style={{ fontSize: 16, fontWeight: 700, margin: "0 0 14px" }}>Public media</h3>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px,1fr))", gap: 14 }}>
        {media.filter((m) => m.public).slice(0, 8).map((m) => (
          <div key={m.id} style={{ aspectRatio: "1/1", borderRadius: 14, background: m.gradient, display: "grid", placeItems: "center" }}>
            {React.createElement((TYPE_META[m.type] || TYPE_META.image).icon, { size: 24, color: "rgba(255,255,255,0.85)" })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
   SETTINGS / STORAGE PAGE
============================================================================ */
function SettingsPage({ user, media, setUser }) {
  const toast = useToast();
  const totalMB = media.reduce((a, m) => a + (Number(m.sizeMB) || 0), 0);
  const used = totalMB / 1024;
  const pct = Math.min(100, (used / STORAGE_TOTAL_GB) * 100);
  const byType = ["3d", "gif", "video", "image"].map((t) => ({
    t,
    size: media.filter((m) => m.type === t).reduce((a, m) => a + (Number(m.sizeMB) || 0), 0)
  }));

  return (
    <div style={{ padding: 24, maxWidth: 720, margin: "0 auto", display: "flex", flexDirection: "column", gap: 22 }}>
      <div className="glass" style={{ borderRadius: 18, padding: 22 }}>
        <h3 className="f-display" style={{ fontSize: 16, fontWeight: 700, margin: "0 0 16px", display: "flex", alignItems: "center", gap: 8 }}><HardDrive size={17} color="var(--violet)" /> Storage</h3>
        <div style={{ fontSize: 22, fontWeight: 700 }} className="f-display">{used.toFixed(2)} GB <span style={{ fontSize: 14, color: "var(--text-faint)", fontWeight: 500 }}>/ {STORAGE_TOTAL_GB} GB limit</span></div>
        <div style={{ height: 8, borderRadius: 6, background: "var(--bg-elev-2)", marginTop: 12, marginBottom: 18, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg,var(--violet),var(--cyan))" }} />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {byType.map(({ t, size }) => (
            <div key={t} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 13 }}>
              <span style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--text-dim)" }}>
                <span style={{ width: 9, height: 9, borderRadius: 3, background: (TYPE_META[t] || TYPE_META.image).color }} />{(TYPE_META[t] || TYPE_META.image).label}
              </span>
              <span className="f-mono">{fmtSize(size)}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize: 12, color: "var(--text-faint)", marginTop: 16, lineHeight: 1.6 }}>
          {(STORAGE_TOTAL_GB - used).toFixed(2)} GB remaining in your Supabase Storage quota.
        </p>
      </div>

      <div className="glass" style={{ borderRadius: 18, padding: 22 }}>
        <h3 className="f-display" style={{ fontSize: 16, fontWeight: 700, margin: "0 0 16px" }}>Account</h3>
        <TextField label="Display name" icon={UserCircle2} value={user.name} onChange={(e) => setUser((u) => ({ ...u, name: e.target.value }))} />
        <TextField label="Email" icon={Mail} value={user.email} onChange={(e) => setUser((u) => ({ ...u, email: e.target.value }))} />
        <Button onClick={() => toast("Account settings saved.")}>Save changes</Button>
      </div>
    </div>
  );
}

/* ============================================================================
   ADMIN DASHBOARD (REAL DATABASE METRICS)
============================================================================ */
function AdminPage({ media, deleteMedia }) {
  const toast = useToast();
  const [confirm, setConfirm] = useState(null);
  const [adminUsers, setAdminUsers] = useState([]);
  const [reportedFiles, setReportedFiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAdminData() {
      try {
        const [uList, rList] = await Promise.all([
          adminService.getRecentUsers(),
          adminService.getReportedMedia(),
        ]);
        setAdminUsers(uList);
        setReportedFiles(rList);
      } catch (err) {
        console.warn("Could not load admin stats:", err);
      } finally {
        setLoading(false);
      }
    }
    loadAdminData();
  }, []);

  const totalViews = media.reduce((a, m) => a + (Number(m.views) || 0), 0);
  const totalMB = media.reduce((a, m) => a + (Number(m.sizeMB) || 0), 0);

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 28 }} className="stat-grid">
        <StatCard icon={Users} label="Registered users" value={adminUsers.length || "—"} delta="+8%" color="var(--violet)" />
        <StatCard icon={UploadCloud} label="Total uploads" value={media.length} delta="+4%" color="var(--cyan)" />
        <StatCard icon={HardDrive} label="Total storage" value={fmtSize(totalMB)} color="var(--amber)" />
        <StatCard icon={Eye} label="Total views" value={totalViews.toLocaleString()} delta="+19%" color="var(--success)" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }} className="admin-grid">
        <div>
          <h3 className="f-display" style={{ fontSize: 16, fontWeight: 700, margin: "0 0 14px" }}>Recent users</h3>
          <div className="glass" style={{ borderRadius: 16, overflow: "hidden" }}>
            {adminUsers.length === 0 ? (
              <div style={{ padding: 20, color: "var(--text-faint)", fontSize: 13, textAlign: "center" }}>No other users yet.</div>
            ) : (
              adminUsers.map((u, i) => (
                <div key={u.id || u.email} style={{ display: "flex", alignItems: "center", gap: 12, padding: 14, borderBottom: i < adminUsers.length - 1 ? "1px solid var(--border)" : "none" }}>
                  <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#7C5CFF,#3DD9EB)", display: "grid", placeItems: "center", color: "#fff", fontWeight: 700, fontSize: 13 }}>{u.name[0]}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{u.name} {u.role === 'admin' && <Badge tone="cyan">ADMIN</Badge>}</div>
                    <div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>{u.email} · {u.uploads} uploads</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div>
          <h3 className="f-display" style={{ fontSize: 16, fontWeight: 700, margin: "0 0 14px", display: "flex", alignItems: "center", gap: 7 }}>
            <FileWarning size={16} color="var(--danger)" /> Reported files
          </h3>
          <div className="glass" style={{ borderRadius: 16, overflow: "hidden" }}>
            {reportedFiles.map((m, i) => (
              <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: 14, borderBottom: i < reportedFiles.length - 1 ? "1px solid var(--border)" : "none" }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: "var(--violet-soft)", flexShrink: 0, display: "grid", placeItems: "center" }}>
                  <FileWarning size={18} color="var(--danger)" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</div>
                  <div style={{ fontSize: 11.5, color: "var(--danger)" }}>{m.reason}</div>
                </div>
                <Button size="sm" variant="danger" onClick={() => setConfirm({ type: "file", id: m.id, label: m.name })}>Remove</Button>
              </div>
            ))}
            {reportedFiles.length === 0 && <div style={{ padding: 24, textAlign: "center", color: "var(--text-faint)", fontSize: 13 }}>No reported files.</div>}
          </div>
        </div>
      </div>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} danger
        title="Remove this file?"
        message={`"${confirm?.label}" will be permanently removed from the platform.`}
        onConfirm={() => { if (confirm?.type === "file") deleteMedia(confirm.id); toast("Removed successfully."); }} />
      <style>{`@media (max-width: 900px){ .admin-grid { grid-template-columns: 1fr !important; } }`}</style>
    </div>
  );
}

/* ============================================================================
   APP SHELL WRAPPER
============================================================================ */
function AppShell({ view, go, user, setUser, children, showSearch, search, setSearch, title, isAdmin, totalSizeMB }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div style={{ display: "flex" }}>
      <Sidebar view={view} go={go} user={user} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} isAdmin={isAdmin} totalSizeMB={totalSizeMB} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <TopBar setMobileOpen={setMobileOpen} title={title} search={search} setSearch={setSearch} showSearch={showSearch} />
        {children}
      </div>
    </div>
  );
}

/* ============================================================================
   ROOT APP (CONNECTS SUPABASE AUTH + REAL MEDIA + SESSIONS)
============================================================================ */
const VIEW_TITLES = {
  dashboard: "Dashboard", upload: "Upload media", library: "My Media", favorites: "Favorites",
  collections: "Collections", shared: "Shared Media", settings: "Settings", profile: "Profile",
  details: "Media details", admin: "Admin",
};

export default function App() {
  const [theme, setTheme] = useState("dark");
  const [view, setView] = useState("landing");
  const [user, setUser] = useState({ id: null, name: "Guest", email: "", role: "user" });
  const [authed, setAuthed] = useState(false);
  const [media, setMedia] = useState([]);
  const [loadingMedia, setLoadingMedia] = useState(true);
  const [activeMedia, setActiveMedia] = useState(null);
  const [search, setSearch] = useState("");
  const [shareTarget, setShareTarget] = useState(null);
  const toast = useToast();

  const isAdmin = user.role === "admin" || user.email === "jordan@studio.io";

  useEffect(() => { document.documentElement.setAttribute("data-theme", theme); }, [theme]);

  // Load Session and set up Realtime Auth State Listener
  useEffect(() => {
    async function initSession() {
      try {
        const session = await authService.getCurrentSession();
        if (session && session.user) {
          const profile = await authService.getUserProfile(session.user.id);
          setUser({
            id: session.user.id,
            email: session.user.email,
            name: profile?.full_name || session.user.user_metadata?.full_name || session.user.email?.split("@")[0] || "Creator",
            role: profile?.role || "user",
            bio: profile?.bio,
          });
          setAuthed(true);
          setView("dashboard");
        }
      } catch (err) {
        console.warn("Session init error:", err);
      }
    }
    initSession();

    // Check URL parameters for direct share token view
    const urlParams = new URLSearchParams(window.location.search);
    const sharedToken = urlParams.get("share");
    if (sharedToken) {
      mediaService.fetchByShareToken(sharedToken).then((m) => {
        if (m) {
          setActiveMedia(m);
          setView("details");
        }
      });
    }

    const { data: authListener } = authService.onAuthStateChange(async (event, session) => {
      if (session && session.user) {
        const profile = await authService.getUserProfile(session.user.id);
        setUser({
          id: session.user.id,
          email: session.user.email,
          name: profile?.full_name || session.user.user_metadata?.full_name || session.user.email?.split("@")[0] || "Creator",
          role: profile?.role || "user",
          bio: profile?.bio,
        });
        setAuthed(true);
      } else if (event === "SIGNED_OUT") {
        setUser({ id: null, name: "Guest", email: "", role: "user" });
        setAuthed(false);
        setView("landing");
      }
    });

    return () => {
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  // Fetch Media whenever User / Auth State changes
  const loadMedia = useCallback(async () => {
    setLoadingMedia(true);
    try {
      if (isSupabaseConfigured() && user.id) {
        const items = await mediaService.fetchMediaList({ userId: user.id });
        setMedia(items);
      } else {
        setMedia([]);
      }
    } catch (err) {
      console.warn("Could not load media:", err);
      setMedia([]);
    } finally {
      setLoadingMedia(false);
    }
  }, [user.id]);

  useEffect(() => {
    loadMedia();
  }, [loadMedia]);

  const go = (v) => {
    if (["dashboard", "upload", "library", "favorites", "collections", "shared", "settings", "profile", "details", "admin"].includes(v) && !authed) {
      setView("login");
      return;
    }
    setView(v);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openDetails = (m) => { setActiveMedia(m); setView("details"); window.scrollTo(0, 0); };

  const toggleFav = async (id) => {
    const target = media.find((m) => m.id === id);
    if (!target) return;
    const nextStatus = !target.favorite;
    setMedia((ms) => ms.map((m) => m.id === id ? { ...m, favorite: nextStatus } : m));
    if (activeMedia?.id === id) setActiveMedia((prev) => ({ ...prev, favorite: nextStatus }));

    try {
      await mediaService.toggleFavorite(id, nextStatus);
    } catch (err) {
      console.warn("Could not toggle favorite:", err);
    }
  };

  const togglePublic = async (id) => {
    const target = media.find((m) => m.id === id);
    if (!target) return;
    const nextStatus = !target.public;
    setMedia((ms) => ms.map((m) => m.id === id ? { ...m, public: nextStatus } : m));
    if (activeMedia?.id === id) setActiveMedia((prev) => ({ ...prev, public: nextStatus }));

    try {
      await mediaService.toggleVisibility(id, nextStatus);
    } catch (err) {
      console.warn("Could not toggle visibility:", err);
    }
  };

  const deleteMedia = async (id) => {
    const target = media.find((m) => m.id === id);
    setMedia((ms) => ms.filter((m) => m.id !== id));
    if (activeMedia?.id === id) setActiveMedia(null);

    try {
      await mediaService.deleteMedia(id, target?.filePath);
    } catch (err) {
      console.warn("Could not delete media item:", err);
    }
  };

  const openShare = (m) => setShareTarget(m);

  const logout = async () => {
    try {
      await authService.signOut();
    } catch (err) {
      console.warn(err);
    }
    setAuthed(false);
    setUser({ id: null, name: "Guest", email: "", role: "user" });
    setView("landing");
  };

  const totalSizeMB = media.reduce((a, m) => a + (Number(m.sizeMB) || 0), 0);

  let body;
  if (!authed && ["landing", "login", "signup", "forgot"].includes(view)) {
    body = view === "landing" ? <LandingPage go={go} /> : <AuthPage mode={view} go={go} onAuthSuccess={() => { setView("dashboard"); loadMedia(); }} />;
  } else {
    let inner;
    if (view === "dashboard") inner = <DashboardPage media={media} go={go} openDetails={openDetails} toggleFav={toggleFav} shareMedia={openShare} deleteMedia={deleteMedia} />;
    else if (view === "upload") inner = <UploadPage onUploadSuccess={loadMedia} go={go} userId={user.id} />;
    else if (view === "library") inner = <LibraryPage media={media} search={search} setSearch={setSearch} openDetails={openDetails} toggleFav={toggleFav} shareMedia={openShare} deleteMedia={deleteMedia} go={go} />;
    else if (view === "favorites") inner = <LibraryPage media={media} search={search} setSearch={setSearch} openDetails={openDetails} toggleFav={toggleFav} shareMedia={openShare} deleteMedia={deleteMedia} filterType={(m) => m.favorite} title="Favorites" go={go} />;
    else if (view === "shared") inner = <LibraryPage media={media} search={search} setSearch={setSearch} openDetails={openDetails} toggleFav={toggleFav} shareMedia={openShare} deleteMedia={deleteMedia} filterType={(m) => m.public} title="Shared Media" go={go} />;
    else if (view === "collections") inner = <div style={{ padding: 24 }}><EmptyState icon={Layers} title="No collections yet" message="Group related 3D renders, GIFs, and videos into organized sets." action={<Button icon={Plus}>Create collection</Button>} /></div>;
    else if (view === "settings") inner = <SettingsPage user={user} media={media} setUser={setUser} />;
    else if (view === "profile") inner = <ProfilePage user={user} media={media} setUser={setUser} />;
    else if (view === "details") inner = <DetailsPage media={activeMedia} go={go} toggleFav={toggleFav} togglePublic={togglePublic} deleteMedia={deleteMedia} openShare={openShare} />;
    else if (view === "admin") inner = <AdminPage media={media} deleteMedia={deleteMedia} />;
    else inner = null;

    body = (
      <AppShell view={view} go={go} user={user} setUser={setUser} title={VIEW_TITLES[view] || "Volumetra"} showSearch={false} search={search} setSearch={setSearch} isAdmin={isAdmin} totalSizeMB={totalSizeMB}>
        <ConfigBanner />
        {view !== "details" && view !== "settings" && view !== "profile" && view !== "collections" && (
          <div style={{ padding: "14px 24px 0", display: "flex", justifyContent: "flex-end" }}>
            <button onClick={logout} className="focus-ring" style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", color: "var(--text-faint)", fontSize: 12.5, cursor: "pointer" }}>
              <LogOut size={13} /> Log out
            </button>
          </div>
        )}
        {inner}
      </AppShell>
    );
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <ToastProvider>
        <GlobalStyle />
        <div className="tmp-root">
          {body}
          <ShareModal media={shareTarget} open={!!shareTarget} onClose={() => setShareTarget(null)} togglePublic={togglePublic} />
        </div>
      </ToastProvider>
    </ThemeContext.Provider>
  );
}
