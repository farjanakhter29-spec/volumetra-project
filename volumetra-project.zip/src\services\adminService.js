import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

export const adminService = {
  // Fetch real admin stats
  async getAdminOverview() {
    if (!isSupabaseConfigured()) {
      return {
        totalUsers: 0,
        totalUploads: 0,
        totalStorageMB: 0,
        totalViews: 0,
        typeStorage: { '3d': 0, gif: 0, video: 0, image: 0 },
      };
    }

    const [usersRes, mediaRes] = await Promise.all([
      supabase.from('profiles').select('id', { count: 'exact' }),
      supabase.from('media').select('file_size, views, file_type'),
    ]);

    const totalUsers = usersRes.count || 0;
    const mediaList = mediaRes.data || [];

    let totalViews = 0;
    let totalBytes = 0;
    const typeStorage = { '3d': 0, gif: 0, video: 0, image: 0 };

    mediaList.forEach((m) => {
      totalViews += Number(m.views || 0);
      totalBytes += Number(m.file_size || 0);
      const t = m.file_type || 'image';
      typeStorage[t] = (typeStorage[t] || 0) + (Number(m.file_size || 0) / (1024 * 1024));
    });

    return {
      totalUsers,
      totalUploads: mediaList.length,
      totalStorageMB: totalBytes / (1024 * 1024),
      totalViews,
      typeStorage,
    };
  },

  // Fetch registered users with upload counts
  async getRecentUsers() {
    if (!isSupabaseConfigured()) return [];

    const { data: profiles, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, role, created_at')
      .order('created_at', { ascending: false })
      .limit(10);

    if (error || !profiles) return [];

    // Fetch upload counts for these users
    const userIds = profiles.map((p) => p.id);
    const { data: mediaData } = await supabase
      .from('media')
      .select('user_id')
      .in('user_id', userIds);

    const counts = {};
    (mediaData || []).forEach((m) => {
      counts[m.user_id] = (counts[m.user_id] || 0) + 1;
    });

    return profiles.map((p) => ({
      id: p.id,
      name: p.full_name || p.email.split('@')[0],
      email: p.email,
      role: p.role,
      uploads: counts[p.id] || 0,
      joined: new Date(p.created_at).toLocaleDateString(undefined, { month: 'short', year: 'numeric' }),
    }));
  },

  // Fetch reported media items
  async getReportedMedia() {
    if (!isSupabaseConfigured()) return [];

    const { data, error } = await supabase
      .from('reports')
      .select('id, reason, status, media:media_id (id, title, file_name, file_type, file_path, file_url, file_size)')
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data.filter((r) => r.media).map((r) => ({
      reportId: r.id,
      id: r.media.id,
      name: r.media.title || r.media.file_name,
      type: r.media.file_type,
      filePath: r.media.file_path,
      url: r.media.file_url,
      reason: r.reason,
      status: r.status,
    }));
  },

  // Submit report for file
  async reportMedia(mediaId, reporterId, reason) {
    if (!isSupabaseConfigured()) return;

    const { error } = await supabase
      .from('reports')
      .insert({
        media_id: mediaId,
        reporter_id: reporterId || null,
        reason: reason || 'Inappropriate content',
        status: 'pending',
      });

    if (error) throw error;
  },

  // Delete media as admin (moderation)
  async deleteMediaAdmin(mediaId, filePath) {
    if (!isSupabaseConfigured()) return;

    // Delete DB record
    await supabase.from('media').delete().eq('id', mediaId);

    // Delete from storage
    if (filePath) {
      await supabase.storage.from('media').remove([filePath]);
    }
  },
};
